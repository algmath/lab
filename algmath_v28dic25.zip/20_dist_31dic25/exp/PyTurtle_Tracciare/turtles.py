# File: turtles.py - <PyTurtle>
# Date: 30 dic 25
# Note: la grafica della tartaruga 
#       modalita' object-oriented
#       argomenti: tartarughe, oggetti, array
#
# Accetta comandi dalla linea di comando:
#   t1.move(Point(2,3))
#   t1.draw(Point(4,1))
#   t1.left(45)

# inseguimento fra 2 t.
def inseguimento():
    t1 = Turtle(color='red')  
    t2 = Turtle(color='blue')
    
    #message('seleziona punto di partenza della tartaruga...')
    mes = 'seleziona punto di partenza della tartaruga...'
    t1.move(Point(INPUT,msg=mes,state=DRAGGABLE,color=t1.getcolor())) #trascinabile
    #t1.move(Point(-2,1))
    
    message('')
    setmode(0) #esce dal modo INPUT e permette il drag del punto
    t2.move(Point(7,3))
    
    #t1.write('t1 parte da qui')  #da implementare in Pen [13mag22]
    #t2.write('t2 parte da qui')
    
    #t2.point()
   
    t1.show()
    t2.show()
    #print('------ turtles: prima di assegnazione ----')
    p = t2.pos()
    #print('------ turtles: passata assegnazione ----')
    #write('DIST t1-t2 =',t1.dist(t2.pos())) #basta qui: e' un valore dinamico
    while t1.dist(t2.pos())>.01:
        #write('DIST t1-t2 =',t1.dist(t2.pos())) #non e' dinamico
        #t1.forward(.1)     # piu' lenta
        #t2.forward(.11)    # piu' veloce
        t1.forward(.05)     # piu' lenta - OK .05
        t2.forward(.06)    # piu' veloce
        t1.left(1)          # ruota di poco - era 3
        t2.look(t1.pos())   # orienta verso t1
        #t2.write('o')     # marker
       

#---- spirale di tartarughe ---- 
# n: numero di t.
def spiraletar(n:int):
    #t = n*[Turtle()]  #riferimenti ad uno stesso oggetto
    t = n*[None]
    colors = ['red','green','blue','orange','brown']
    for i in range(n):
        #t[i] = Turtle()
        #t[i].setcolor(colors[i % len(colors)])
        #t[i].setwidth(1)
        t[i] = Turtle(color=colors[i%len(colors)],width=1)
        t[i].left(360/n*i)
        t[i].show()

    for _ in range(40):
        for i in range(n):
           t[i].forward(.2)
           t[i].left(5)

#---- main ----
clear()
#inseguimento()    # inseguimento di 2 tartarughe 
spiraletar(7)      # spirale di tartarughe


