# File: figure.py 
# Date: 16 nov 25
# Note: disegno di figure (quadrato con diagonali, ...)

# quadrato di con diagonali di semilunghezza l
# con uso di push e pop
def quadratocondiagonali(lato:int):
    for _ in range(4):
        push()
        push()
        jump(lato)
        P = pos()
        pop()
        right(90)
        forward(lato)
        draw(P)
        pop()
        right(90)

#croce a 4 braccia
def croce4braccia(lato:int):
    for _ in range(4):  
        push()
        forward(lato)
        push()
        right(45)
        forward(lato)
        pop()   #esercizio: cosa avviene togliendo questa pop?
        #pop() x   # ERRORE segnalato correttamente
        #x = y     # ERRORE segnalato correttamente
        left(45)
        forward(lato)
        pop()
        left(90)


'''
#sole con raggi - ok 17feb23
n = 11 # numero raggi
l = 3  # lunghezza raggi
for _ in range(n):
    push()
    forward(l)
    pop()
    left(360/n)
'''

'''
#---- 3 esagono --  ok 26feb23
# commentando le linee # si ottiene una figura aperta
l = 3  # lunghezza tratti
for _ in range(3):   #6
    push()
    forward(l)
    push()
    right(60)
    forward(l)
    right(60)  #
    forward(l) #
    pop()
    left(60)
    forward(l)
    left(60)   #
    forward(l) #
    pop()
    left(120)
#'''

'''    
#altra modalita': - ok 26feb23
for _ in range(3):   
    push()
    for _ in range(5):
        forward(l)
        left(60)
    pop()
    left(120)
'''    

        
#---- main ----
clear()
home()
setcolor('red')
quadratocondiagonali(2)
move(Point(2,3,state=INVISIBLE))
setcolor('blue')
croce4braccia(2)




    



    
