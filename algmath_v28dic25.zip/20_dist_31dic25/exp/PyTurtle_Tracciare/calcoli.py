# File: calcoli.py - <PyTurtle>
# Date: 30 dic 25
# Note: calcoli mediante la tartaruga

# radice di 2
def radice2():
    P = pos()
    jump(1)
    left(90)
    jump(1)
    #Q = pos()
    #display('Q=',Q)
    return dist(P)

# radice di n
def radice(n:int) -> float:
    P = pos()   #SERVE FARE UN clone? 
    jump(1)
    for _ in range(n-1):
        look(P)
        right(90)
        jump(1)
    #x = dist(P)
    #write('x=',x)
    return dist(P)

              
#---- main ----
clear()
home()
hide()

'''
#print('radice(2)=',radice2())
xprint('radice(2)=',radice2())
'''

for n in range(1,17):
    print(f'radice({n})=',radice(n),tim=0)  #sulla linea di comando
    display(f'radice({n})='+str(radice(n)))   #sulla finestra grafica delle label di comando
    #debug ... print(f'radice({n})=',radice(n))        #sul terminale dell'idle
    






    
