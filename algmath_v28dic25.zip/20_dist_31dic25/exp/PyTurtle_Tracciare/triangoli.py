# File: triangoli.py
# Date: 15 nov 25
# Note: disegno di triangoli

# triangolo di dati vertici
def triangolo(A:Point,B:Point,C:Point) -> None:
    move(A)
    draw(B)
    draw(C)
    draw(A)

# triangolo rettangolo di cateti a e b
def triangoloRettangolo(a:float,b:float) -> None:
    P = pos()
    setangle(90)
    forward(a)
    A = pos()
    move(P)
    right(90)
    forward(b)
    draw(A)
       
#---- main ----
clear()
A = Point(1,2)
B = Point(4,1)
C = Point(2,4)
setcolor('red')
triangolo(A,B,C)

#color('green')
#forward(2)
jump(3)
setcolor('blue')
triangoloRettangolo(2,3)


       

    



    
