# File: teodoro.py - <PyTurtle>
# Date: 30 dic 25
# Note: spirale di Teodoro 

# spirale di Teodoro con n lati
#
def teodoro(n:int):
    P = pos()  #posizione iniziale
    setcolor('black')
    setwidth(2)
    jump(1)
    for i in range(n):
        #''' solo bordo:
        look(P)
        right(90)
        forward(1)
        #write(dist(P))
        #write('"sqrt('+str(i+2)+')='+str(dist(P)))
        #point()  #punto sulla posizione
        #'''

        '''
        #con raggi:
        Q = pos()
        setcolor('gray')
        setwidth(1)
        #look(P)
        draw(P)
        move(Q)
        look(P)
        #jump(Q)  #ERR MAL SEGNALATO
        right(90)
        setcolor('black')
        setwidth(2)
        pendown()
        forward(1)
        '''
    
# disegno di un grafo completo di n lati di lunghezza l - ok
def grafo4(n:int,l:float):
    a = 360/n
    for i in range(n):
        P = pos()
        jump(l)
        left(a)
        push()
        for j in range(i+1,n+1):
            push()
            draw(P)
            pop()
            jump(l)
            left(a)
        pop()
    
#---- main ----
clear()
setcolor('red')
home()
right(90)
teodoro(20)





    



    
