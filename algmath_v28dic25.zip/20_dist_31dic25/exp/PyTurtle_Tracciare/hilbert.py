# File: hilbert.py - ok
# Date: 30 dic 25
# Note: curva di Hilbert
#       applicazione <PyTurtle>

'''
#parte per provare l'import di moduli esterni
sys.path.append('../prog/Tracciare')
#from modulo import *
import modulo #usare modulo.ciao()

def saluto():  #solo per test
    print('SALUTO da hilbert')
'''

# cfr. Turtle Geometry: The Computer as a Medium for Exploring Mathematics
# by Harold Abelson and Andrea diSessa p. 96-98
# l : lunghezza tratto
# n : ordine di ricorsione
# k : verso di avanzamento (-1,1)
#
def hilbert(l:float, n:int, k=1):
    #saluto()
    if n > 0:
        left(k*90)
        hilbert(l,n-1,-k)
        forward(l)
        right(k*90)
        hilbert(l,n-1,k)
        forward(l)
        hilbert(l,n-1,k)
        right(k*90)
        forward(l)
        hilbert(l,n-1,-k)
        left(k*90)
       
#---- main ----
clear()
home()
setcolor('red')
#n = 3 #ordine di ricorsione
n = int(input('ordine di ricorsione:'))  #ok
#n = int(read('n=',init='2',check=lambda s:int(s)<6,warning='numero troppo grande'))  #ok
#n = int(input('n=',init='2',check=lambda s:int(s)<6,warning='numero troppo grande'))  #ok  old
#n = int(input('n=',init='2',check=lambda s: return True if int(s)<6:'numero troppo grande'))  #NO
#setcolor('red')
show()

#ciao()  #definita in modulo.py
#modulo.ciao()  #definita in modulo.py
#hilbert(.5,4)
hilbert(.5,n)
#xxyy  #errore
hide()



    



    
