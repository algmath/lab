# File: poli_turtle.py - ok
# Date: 30 dic 25
# Note: poligono con vertici mobili creato con la t.

# poligono con vertici mobili
# argomenti:
#   n : numero di lati del poligono
#   l : lunghezza del lato
#
def polimobile(n:int,l:float):
    Q = None #punto precedente
    for i in range(n):
        push()
        jump(l)
        P = pos()
        if i==0: S = P #primo vertice
        P.config(state=DRAGGABLE,color=getcolor(),name='P'+str(i+1))
        pop()
        left(360/n)
        if not Q is None: Segment(P,Q) 
        Q = P
    Segment(S,Q) #primo-ultimo vertice
        
#---- main ----
clear()
polimobile(8,2)
