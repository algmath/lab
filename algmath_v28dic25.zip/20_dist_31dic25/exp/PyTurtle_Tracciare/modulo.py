# File: modulo.py - ok
# Date: 12 feb 25
# Note: modulo per provare gli import

from gwinter import * 

def ciao():
    left(45)
    forward(2)
    print('CIAO dal modulo')




    



    
