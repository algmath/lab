# File: grafi.py 
# Date: 16 nov 25
# Note: disegno di un grafo completo 

# disegno di un grafo completo
# di n lati di lunghezza l
def grafo(n:int,l:float):
    # calcolo dei vertici del grafo,
    # memorizzati nella sequenza P
    P = n*[None]  
    for i in range(n):
        #P[i] = dpos()  #riferimento dinamico: NO
        P[i] = pos()
        #forward(l)
        jump(l)
        left(360/n)
        #write('Pi=',P[i])
        #point()

    #for i in range(n): print(' ->P[i]=',coordsvalues(P[i]))
    #print('---->  P[3]=',coordsvalues(P[3]))

    # disegno del grafo
    for i in range(n):
        for j in range (i+1,n):
            #write('Px=',P[i])
            #write('  Py=',P[j])
            #print('i=',i,'  Pi=',coordsvalues(P[i]))
            #print('j=',j,'  Pj=',coordsvalues(P[j]))
            move(P[i])
            draw(P[j])            
  

# disegno di un grafo completo di n lati di lunghezza l - ok, ma lento (3 cicli)
def grafo2(n:int,l:float):
    # punti base
    A = pos()
    forward(l)
    B = pos()
    for i in range(n):
        for j in range(n):
            move(A)
            look(B) 
            for k in range(j):
                forward(l)
                left(360/n)
            draw(A) #disegno
        A = B
        look(B)
        forward(l)
        left(360/n)
        forward(l)
        B = pos()

# disegno di un grafo completo di n lati di lunghezza l - ok
def grafo3(n:int,l:float):
    for i in range(n):
        P = pos()
        a = getangle()
        for j in range(i+1,n+1):
            for _ in range(j-i):
                jump(l)
                left(360/n)
            draw(P) #disegno
            setangle(a)
        jump(l)
        left(360/n)
    
# disegno di un grafo completo di n lati di lunghezza l - ok
def grafo4(n:int,l:float):
    a = 360/n
    for i in range(n):
        P = pos()
        jump(l)
        left(a)
        push()
        for j in range(i+1,n+1):
            push()
            draw(P)
            pop()
            jump(l)
            left(a)
        pop()
    

#disegno di un grafo completo di n vertici e dato lato
#cfr. grafo() all'inizio
def grafo5(n:int,lato:float) -> None:
    a = [] # array dei vertici
    penup()
    for i in range(n):
        a += [pos()]
        forward(lato)  
        left(360/n)
    pendown()
    for i in range(n):
        for j in range(i+1,n):
            move(a[i])
            draw(a[j])

    
#---- main ----
clear()
setstate(INVISIBLE) #punti di move invisibili
setcolor('blue')
move(Point(4,5))
grafo(7,3)
setcolor('black')
move(Point(-3,2))
grafo2(9,3.2)     #molto lento; migliorabile?
setcolor('red')
move(Point(11,1))
grafo3(7,3.2)
setcolor('brown')
move(Point(4,-5))
grafo4(9,3.2)
setcolor('orange')
move(Point(10,8))
grafo5(5,3.5)




    



    
