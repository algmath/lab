# File: poligoniOO.py - ok
# Date: 30 dic 25
# Note: disegno di poligoni in modalita' procedurale ed OO
#       ... ma sarebbe meglio estendere Turtle [30mag25]

# disegno di un poligono
# di n lati di lunghezza l
def poligono(l:float,n:int) -> None:
    for _ in range(n):
        forward(l)
        left(360/n)

# disegno di un poligono in modalita' OO
# di n lati di lunghezza l
def poligonoOO(l:float,n:int,t:Turtle) -> None:
    for _ in range(n):
        t.forward(l)
        t.left(360/n)
       
#===========================================
clear()
home()
pendown()
setcolor('red')
poligono(2,6) #esagono di lato 2

nina = Turtle(color='blue')
#nina.move(Point((2,2)))   #ok
#nina.move(Point(2,2))  #ok
nina.move(Point(2,2,state=INVISIBLE))  #ok
poligonoOO(2,6,nina)

nina.setcolor('brown')
nina.move(Point(3,-2,state=INVISIBLE))  
poligonoOO(2.5,5,nina)





    



    
