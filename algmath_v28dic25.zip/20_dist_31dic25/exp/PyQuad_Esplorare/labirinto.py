# File: labirinto.py - <PyQuad>
# Date: 28 dic 25
# Note: uscita da un labirinto

from mod_ostacoli import *  #modulo locale presente nel path dell'append sopra

# creazione del labirinto
def crealabirinto():
    for _ in range(1,9): wall(_,1)
    for _ in range(1,9): wall(_,8)
    for _ in range(4,9): wall(1,_)
    for _ in range(1,9): wall(8,_)
    wall(1,2)
    wall(2,2)
    wall(6,2)
    wall(3,3)
    wall(4,3)
    wall(4,4)
    wall(6,4)
    wall(3,5)
    wall(6,5)
    wall(3,6)
    wall(4,6)
    wall(5,6)
    wall(7,7)
 
def sulbordo() -> bool:
    return posc() in (1,8) or posr() in (1,8)

# esce dal labirinto, fermandosi sul bordo
def escilabirinto(): 
    while not sulbordo():
        striscia()
        #print('strisciato')
        #foo.striscia()

#---- main ----
crealabirinto()
#loadboard('../exp/PyQuad_Esplorare/labirinto1.brd') 
locate(3,2,EAST)  #posiziona Quadretto
escilabirinto()





