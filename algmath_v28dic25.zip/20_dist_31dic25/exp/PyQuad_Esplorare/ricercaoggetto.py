# File: ricercaoggetto.py - ok
# Date: 28 dic 25
# Note: ricerca un oggetto all'interno della scacchiera

# TRUE se e solo se tocca il bordo della scacchiera
#
def toccabordo():
    x, y, v = posc(), posr(), angle() #stato corrente
    return (x==1 and v==WEST) or \
           (x==8 and v==EAST) or \
           (y==1 and v==SOUTH) or \
           (y==8 and v==NORTH)  

# TRUE se e solo se tocca l'oggetto
#
def toccaoggetto():
    return touch() and not toccabordo()
    
# ricerca un oggetto interno alla scacchiera
#
def ricercaoggetto():
    #tenta di portarti in un angolo:
    for _ in range(2):
        while not toccaoggetto() and not toccabordo():
            forward()
        if not toccaoggetto():
            right()

    #ricerca sistematica su un percorso a serpentina:
    curva = True
    while not toccaoggetto():
        forward()
        if toccabordo():
            for _ in range(2):
                if not toccaoggetto():
                    if curva:
                        right()
                    else:
                        left()
                if not toccaoggetto():
                    forward()
            curva = not curva

#----------------------------------------------

#aggira l'oggetto verso destra
def aggiradx():
    right()
    forward()
    left()
    forward()
    left()

#aggira l'oggetto verso sinistra
def aggirasx():
    left()
    forward()
    right()
    forward()
    right()

# dopo aver trovato un blocco unitario staccato dal muro perimetrale,
# lo spinge in un angolo
#
def spingiangolo():

    #aggiramento blocco per spingerlo sul lato sinistro
    aggiradx() if angle()==NORTH else aggirasx()
    
    #spinta sul lato sinistro
    while not blocked():
        forward()

    #aggiramento oggetto per spingerlo in basso 
    aggiradx()

    #spinta in basso, in (1,1)
    while not blocked():
        forward()
  
#---- main ----
ricercaoggetto()
spingiangolo()


