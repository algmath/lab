# File: perimetro.py - <PyQuad> 
# Date: 28 dic 25
# Note: misura il perimetro dell'oggetto posto davanti e poi si ferma

from mod_ostacoli import * #modulo presente in ../lib

# misura il perimetro dell'ostacolo posto davanti e poi si ferma
def perimetro() -> int: 
    affianca()
    p = 0
    xi, yi = posc(), posr() #posizione iniziale
    while True:
        striscia()
        p += 1
        if posc()==xi and posr()==yi: break
    return p

#---- main ----
p = perimetro()
print('perimetro = ',p)

#striscia()

