# File: circumnaviga.py 
# Date: 28 dic 25
# Note: circuita un oggetto e ritorna al punto di partenza

sys.path.append('../exp/Esplorare_PyQuad')
from mod_ostacoli import *

# circuita un oggetto e ritorna al punto di partenza
def circumnaviga(): 
    x, y, v = posc(), posr(), angle() #stato iniziale
    affianca()
    while True:
        striscia()
        if ((posc()==x) and (posr()==y)): break
    orienta(v)
    
#---- main ----
loadboard('../exp/Esplorare_PyQuad/costeggia.brd') 
#locate(3,2,EAST)  #posiziona Quadretto
right()
circumnaviga()
