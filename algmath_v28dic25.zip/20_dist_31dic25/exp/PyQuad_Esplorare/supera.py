# File: supera.py 
# Date: 28 dic 25
# Note: supera l'oggetto davanti e si orienta in avanti dritto

sys.path.append('../exp/Esplorare_PyQuad')
from mod_ostacoli import *

# supera l'oggetto davanti e poi prosegue dritto - ok
def supera(): 
    contatta()
    x0, y0, v0 = posc(), posr(), angle() #stato iniziale
    superato = sulbordo()
    while not superato:
        striscia()
        xc, yc = posc(), posr()
        if ((v0==NORTH) and (xc==x0) and (yc>y0))  or \
           ((v0==SOUTH) and (xc==x0) and (yc<y0))  or \
           ((v0==EAST)  and (xc>x0)  and (yc==y0)) or \
           ((v0==WEST)  and (xc<x0)  and (yc==y0)): 
            right()
            superato = True
        #print(f'x0={x0}, y0={y0}, v0={v0}   xc={xc}, yc={yc}, superato={superato}')
    orienta(v0)
    
#---- main ----
while not sulbordo():
    supera()

