# File: costeggia.py - <PyQuad>
# Date: 28 dic 25
# Note: costeggia indefinitamente l'oggetto al quale si e' a contatto

sys.path.append('../exp/Esplorare_PyQuad')
from mod_ostacoli import *

# creazione del labirinto
def costeggia():
    affianca()
    while True:
        striscia()
        
#---- main ----
loadboard('../exp/Esplorare_PyQuad/costeggia.brd')  
#locate(3,2,EAST)  #posiziona Quadretto
right()
costeggia()
#striscia()





