# File: area.py - <PyQuad> 
# Date: 28 dic 25
# Note: calcolo dell'area occupata da un oggetto staccato dal bordo

sys.path.append('../exp/Esplorare_PyQuad') 
from mod_ostacoli import *

# calcola la stringa LFR del percorso attorno all'ostacolo
#
def percorso() -> int: 
    affianca()
    xi, yi = posc(), posr() #posizione iniziale
    p = ''                  #stringa LFR del percorso
    while True:
        #espansione di striscia:
        if touch():
            right()
            p += 'R'
        else:
            forward()
            p += 'F'
            if not tocca(LEFT):
                left()
                forward()
                p += 'LF'
        if posc()==xi and posr()==yi: break
    return p

# calcola dell'area racchiusa dal percorso p
# p e' una stringa di LFR
#
def area(p:str) -> int:
    r = 0       #inizializzazione area
    
    #fissa stato iniziale di riferimento sulla posizione corrente
    x, y = 1, 1 #posizione corrente
    a = 0       #angolo corrente

    i = 0 
    while i<len(p):
        c = p[i]  #carattere corrente del percorso
        #print('char =',c)

        #aggiornamento di (x,y,a) in base a c
        if c=='L':
            a = (a+1)%4
        elif c=='R':
            a = (a-1)%4
        elif c=='F':
            if a==0:   #Nord
                y += 1
            elif a==1: #West
                x -= 1
            elif a==2: #South
                y -= 1
            else:      #East
                x += 1

        #calcolo area
        if c!='L' and ((i+1<len(p) and p[i+1]!='L') or i+1==len(p)):
            if a==3:
                r -= y
            elif a==1:
                r += y-1

        i += 1
      
    return abs(r)

#---- main ----
p = percorso()
#print('P=',p)
a = area(p)
print('area=',str(a))  

