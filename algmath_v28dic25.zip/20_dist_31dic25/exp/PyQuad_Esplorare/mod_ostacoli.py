# File: mod_ostacoli.py - modulo di funzioni per <PyQuad>
# Date: 28 dic 25
# Note: modulo di funzioni semplici per muoversi fra gli ostacoli
#
#       per usare questo modulo:
#
#           sys.path.append('../exp/Esplorare_PyQuad')
#           from mod_ostacoli import *

from qwinter import *

# avanza di n passi
def avanza(n:int):
    for _ in range(n):
        forward()

# ruota a sinistra n volte
def sinistra(n:int):
    for _ in range(n):
        left()

# ruota a destra n volte
def destra(n:int):
    for _ in range(n):
        right()

# inverte il verso (dietro-front)
def inverti():
    destra(2)
   
# orienta secondo il verso v
def orienta(v):
    while angle() != v:
        left()

# True se il lato s tocca un oggetto
# se s is None ritorna True se almeno un lato tocca
#
def tocca(s=None) -> bool:
    if s is None:
        k = 0 #contatore delle rotazioni
        while not touch() and k<4:
            right()
            k += 1
        #print('k =',k)
        ris = touch()
        #ripristino stato iniziale:
        for _ in range(k%4):
            left()
    elif s == FRONT:
        ris = touch()
    elif s==LEFT:
        left()
        ris = touch()
        right()
    elif s==RIGHT:
        right()
        ris = touch()
        left()
    else:
        inverti()
        ris = touch()
        inverti()
    return ris


# orienta verso l'oggetto piu' vicino
def vicino():
    d = dist()
    k = 0 #contatore delle rotazioni
    for i in range(1,4):
        right()
        if dist() < d:
            k = i
            d = dist()
        #print(f'dmin={d}  k={k}')
    destra((1+k)%4)
    

# avanza il r. a fino al contatto con un oggetto (muro o blocco)
def contatta():
    while not touch():
        forward()

# ruota a dx fino a liberare il FRONT del r. 
# ES. Quando libera cade in loop? 
def libera():
    while touch():
        right()
        
# ...
# ES. Cosa succede se non e' verificata la precondizione tocca(LEFT)? 
def striscia():
    if touch():
        right()
    else:
        forward()
        if not tocca(LEFT):
            left()
            forward()

#----------

# porta il r. ad accostarsi con la testa all'oggetto con cui e' in contatto
# oppure avanza sul verso corrente fino a contatto con l'oggetto davanti
def accosta():
    k = 0
    while not touch() and k<4:
        right()
        k += 1
    if not touch():
        contatta()
           
# porta il r. ad affiancare sul lato sx il muro 
def affianca():
    accosta()
    libera()

# costeggia (indefinitivamente) l'ostacolo a contatto o posto davanti
def costeggia():
    #contatta()
    affianca()
    while True:
        striscia()

# circumnaviga (1 giro) l'ostacolo a contatto o posto davanti
def circumnaviga(): 
    #libera()
    affianca()
    #contatta()
    xi, yi = posc(), posr() #posizione iniziale
    while True:
        striscia()
        if posc()==xi and posr()==yi: break
        

# True se Q si trova con la testa sul bordo della scacchiera
def sulbordo():
    x, y, v = posc(), posr(), angle() #stato corrente
    return (((v==NORTH) and (y==8)) or \
            ((v==SOUTH) and (y==1)) or \
            ((v==EAST)  and (x==8)) or \
            ((v==WEST)  and (x==1)))



