# File: input_figure.py - <PyPen> 
# Date: 2 gen 26 
# Note: input di figure composte

clear()

# Note:
# Circle(C,P) : circ. di centro C e passante per P
# Circle(C,r) : circ. di centro C e raggio r
# Circle(C,P1,P2) : circ. di centro C ed apertura P1-P2
# Circle((P1,P2,P3)) : circ. per i 3 punti P1, P2, P3
#
# Circle(INPUT)         circle con input di centro e punto di passaggio
# Circle(INPUT,2)       circle con input di centro e raggio 2
# Circle(INPUT,C)       circle di centro C
# Circle(INPUT,())      circle passante per 3 punti di input
# Circle(INPUT,(P,))    circle passante per P
# Circle(INPUT,(P,Q))   circle passante per P e Q


'''
#input di un triangolo:  
A = Point(INPUT,msg='punto A?',name='A',state=ACTIVE)
B = Point(INPUT,node=A,msg='punto B?',name='B',state=ACTIVE)
Segment(A,B)
C = Point(INPUT,node=(A,B),msg='punto C?',name='C',state=ACTIVE)
Segment(A,C)
Segment(B,C)
'''

'''
#input di un triangolo equilatero:  
A = Point(INPUT,msg='punto A?',name='A',state=ACTIVE)
B = Point(INPUT,node=A,msg='punto B?',name='B',state=ACTIVE)
Segment(A,B)
C = rot(A,B,60).config(name='C',color=getcolor(),state=getstate())
Segment(A,C)
Segment(B,C)
'''

'''
#input di un triangolo isoscele con base AB orizzontale:  
A = Point(INPUT,msg='punto A?',name='A',state=ACTIVE)
a = Line(A,(1,0),color='gray',width=THIN,state=INVISIBLE)
B = Point(INPUT,on=a,node=A,msg='punto B?',name='B',state=ACTIVE)
Segment(A,B)
M = ((A+B)/2)  #.config(state=INVISIBLE)
b = Line(M,rot(M,B,90)).config(state=INVISIBLE)
C = Point(INPUT,on=b,node=(A,B),msg='punto C?',name='C',state=ACTIVE)
Segment(A,C)
Segment(B,C)

#circ inscritto
setcolor('red')
k = dist(A,M)/dist(A,C)
D = hom(A,C,k)
E = hom(B,C,k)
Circle((M,D,E),color='red',state=ACTIVE)
'''

'''
#input di un quadrato traslabile:  
A = Point(INPUT,msg='punto A?',name='A',state=ACTIVE)
a = Line(A,(1,0),state=INVISIBLE)
B = Point(INPUT,on=a,node=A,msg='punto B?',state=INVISIBLE) 
setstate(ACTIVE)
Segment(A,B) #.config(color='blue')
C = rot(A,B,90)
D = rot(B,A,-90)
Segment(A,C)
Segment(B,D)
Segment(C,D)
'''


'''
#input di un punto invisibile: ok
P = Point(INPUT,msg='punto invisibile?',state=INVISIBLE) #si vede B
print('x=',getx(P))
print('y=',gety(P))
'''


'''   
#input di un segmento orizzontale:  
A = Point(INPUT,msg='punto A?',name='A',color='black',state=ACTIVE)
a = Line(A,(1,0),color='gray',width=THIN,state=INVISIBLE)
B = Point(INPUT,on=a,node=A,msg='punto B?',state=INVISIBLE) #si vede B
#B = Point(INPUT,    node=A,msg='punto B?',state=INVISIBLE) #NON si vede B
setstate(ACTIVE)
Segment(A,B).config(color='blue')
'''


'''
#input di un trapezio trascinabile:  
A = Point(INPUT,msg='punto A?',name='A',state=ACTIVE)
a = Line(A,(1,0),color='gray',width=THIN,state=INVISIBLE) 
B = Point(INPUT,on=a,node=A,msg='punto B?',name='B',state=ACTIVE)
Segment(A,B)
C = Point(INPUT,node=B,msg='punto C?',name='C',state=ACTIVE)
Segment(B,C)
b = Line(C,(1,0),color='gray',width=THIN,state=INVISIBLE) 
#D = Point(INPUT,on=b,node=(A,C),msg='punto D?',name='D',state=ACTIVE)
D = Point(INPUT,on=b,node=(C,A),msg='punto D?',name='D',state=ACTIVE)
Segment(D,C)
Segment(A,D)
'''




