# File: usa_Triangolo.py 
# Date: 2 gen 26 
# Note: test della classe Triangolo

#import sys
#sys.path.append('../exp/Disegnare_PyPen')
from Triangolo import *

clear()
setgrid(True)

message('seleziona i tre vertici del triangolo')
t = Triangolo(vertices=('A','B','C'))   #input di un triangolo
message('')

display('area(t)=',area(t))
#write('static area(t)='+str(area(t)))
display('earea(t)=',earea(t))
#write('static earea(t)='+str(earea(t)))
display('fperimetro(t)=',fperimetro(t))
#write('static perimetro(t)='+str(t.perimetro()))

I = incentro(t).config(color='red',state=ATTACHABLE)  
#display('incentro=',I)

c = circcirc(t)
c.config(color='orange',state=VISIBLE)

c1 = circinscr(t).config(color='red',state=ATTACHABLE) 
#display('c1 inscritto=',c1)

c2 = circcirc(t).config(color='green',state=ATTACHABLE)
#display('c2 circoscritto=',c2)









