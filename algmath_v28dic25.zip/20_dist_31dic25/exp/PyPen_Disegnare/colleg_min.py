# File: colleg_min.py - ok
# Date: 28 dic 25 
# Note: collegamento minimo Punto-Retta-Punto 
#       (anche come test per oggetti condizionali)
#       usare in configurazione <PyPen>

sys.path.append('../exp/lib')  #RIM
from costruzioni import * #piede 

clear()
setgrid(True)

s = 'seleziona una retta ...'
r = Line(INPUT,msg=s,name='r',color='blue',state=DRAGGABLE)
s = 'seleziona un punto ...'
P = Point(INPUT,msg=s,name='P',color='blue',state=DRAGGABLE)
s = 'seleziona un altro punto ...'
Q = Point(INPUT,msg=s,name='Q',color='blue',state=DRAGGABLE)

K = hom(Q,piede(Q,r),2) #speculare di Q rispetto a r
K.config(name='K',color='brown',state=VISIBLE)

stessaparte = dist(P,Q)<dist(P,K) 
display('stessaparte=',stessaparte)

s = Line(P,K,width=1,color='blue',name='s',state=ATTACHABLE)
display('s=',s)

M = Intersection(r,s,name='M',color='brown',state=ATTACHABLE)

T = IfPoint(stessaparte,M,P) #punto condizionale  
d1 = dist(T,M)
d2 = T.dist(M)

display('d1=',d1)
display('d2=',d2)
display('M=',M) 
display('P=',P)
display('Q=',Q)
display('T=',T)

s1 = Segment(P,T,color='red',width=3,state=ACTIVE)
display('s1=',s1)   
s2 = Segment(T,Q,color='red',width=3,state=ACTIVE)

setmode(DRAG)

