# File: movimenti.py - <PyPen> 
# Date: 2 gen 26 
# Note: movimento automatico del centro di un circle

from time import sleep

clear()

P = Point((1,2),color='red',state=DRAGGABLE)
Q = Point((-1,-1),color='green',state=DRAGGABLE)
P.config(color='brown')
s = Segment(P,Q,color='orange',name='s',state=DRAGGABLE)

setxy(P,3,4)

c = Circle(P,dist(P,Q)/4).config(state=DRAGGABLE,color='orange')

#movimento
for i in range(100):
    sleep(0.005) #100ms
    k = i/20
    setxy(P,3+k*k-4*k,4-k*k+3*k)
    sleep(0.02) #sec
    update() 

