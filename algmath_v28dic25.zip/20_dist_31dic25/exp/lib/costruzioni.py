# File: costruzioni.py 
# Date: 30 dic 25 
# Note: costruzioni con riga&compasso [cfr. cap. 31]

from gwinter import *   #ok [30ott25]

_cons_color = 'gray'   # colore delle linee di costruzione
_cons_width = 1        # spessore delle linee di costruzione
_cons_state = VISIBLE  # stato delle linee di costruzione

# asse di un segmento
# cfr. Alg. asse - cap. Punteggiare
def asse(A:Point,B:Point) -> Line:
    global _cons_color
    alfa = Circle(A,B,color=_cons_color,width=_cons_width,state=_cons_state)
    beta = Circle(B,A,color=_cons_color,width=_cons_width,state=_cons_state)
    P, Q = inters(alfa,beta)
    P.config(color=_cons_color,width=_cons_width,state=_cons_state)
    Q.config(color=_cons_color,width=_cons_width,state=_cons_state)
    a = Line(P,Q,color=_cons_color,width=_cons_width,state=_cons_state)
    return a

# punto medio fra due punti
# cfr. Alg. medio - cap. Punteggiare
def medio(A:Point,B:Point) -> Point:
    a = asse(A,B).config(color=_cons_color,state=_cons_state)
    r = Line(A,B,color=_cons_color,state=_cons_state,width=_cons_width)
    M = inters(a,r)
    return M 

# simmetrico del punto A rispetto al punto B
def simmetrico(A:Point,B:Point) -> Point:
    K = inters(Line(A,B),Circle(B,A))[0]
    S = IfPoint(A==B,A,K) 
    return S

# retta per il punto A e perpendicolare alla retta r;
# funziona anche nel caso in cui A stia su r
def perp(A:Point,r:Line) -> Line:
    Q = Point(RANDOM,on=r) #,state=_cons_state,color=_cons_color)
    c = Circle(A,Q).config(color=_cons_color,width=_cons_width,state=_cons_state)
    P1, P2 = inters(c,r)  #deve essere P1 != P2
    s = asse(P1,P2)
    s.config(color=_cons_color,width=_cons_width,state=_cons_state) #,expand=False)
    return s

# retta per il punto A e parallela alla retta r
def paral(A:Point,r:Line) -> Line:
    s = perp(A,perp(A,r))
    s.config(color=_cons_color,width=_cons_width,state=_cons_state) #,expand=False)
    return s

# piede del punto P sulla retta r
def piede(P:Point,r:Line) -> Point:
    t = perp(P,r)
    T = inters(t,r)
    T.config(color=_cons_color,width=_cons_width,state=_cons_state) 
    return T

# circonferenza passante per 3 punti
def circonf3punti(A:Point, B:Point, C:Point) -> Circle:
#def Circle(A:Point, B:Point, C:Point) -> Circle:
    a1 = asse(A,B)
    a2 = asse(B,C)
    T = inters(a1,a2)
    g = Circle(T,dist(T,A))
    return g

# centro circonferenza passante per 3 punti
def centrocirconf3punti(A:Point, B:Point, C:Point) -> Circle:
    a1 = asse(A,B)
    a2 = asse(B,C)
    T = inters(a1,a2)
    return T

# centro di una circonferenza c (equivale alla center(c))
# cfr. Alg. ... cap. Disegnare
def centro(c:Circle) -> Point:
    global _cons_color
    P = Point(RANDOM,on=c) #,color=_cons_color,state=_cons_state)
    Q = Point(RANDOM,on=c) #,color=_cons_color,state=_cons_state)
    R = Point(RANDOM,on=c) #,color=_cons_color,state=_cons_state)
    C = centrocirconf3punti(P,Q,R)
    return C

# diametro di a passante per A
def diametro(a:Circle,A:Point) -> Segment:
    C = centro(a)
    r = Line(A,C)
    P, Q = inters(r,a)
    s = Segment(P,Q)
    return s

# tangenti alla circonferenza a condotte per il punto esterno P
# cfr. par. Costruzioni nel cap. PUNTEGGIARE
def tangenti(a:Circle,P:Point):
    C = centro(a)#.config(state=VISIBLE,color=_cons_color) 
    M = medio(C,P)#.config(state=VISIBLE,color=_cons_color) 
    b = Circle(M,C).config(state=VISIBLE,color=_cons_color,width=_cons_width)       
    S, T = inters(a,b)
    return (S,T)


