# File: riempi.py 
# Date: 30 dic 24
# Note: riempie la scacchiera con numeri

#numeri per 'eseguire' la divisione
n = 8
for c in range(n):
    for r in range(n):
        write(c+1,r+1,str(r))


