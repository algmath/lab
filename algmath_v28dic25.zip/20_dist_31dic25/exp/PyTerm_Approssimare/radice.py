# File: radice.py
# Date: 2 gen 26
# Note: rad(2) = 1,4142135623730950488016887242097
#       applicazione <PyTerm>

# calcolo della radice di x - metodo dei dimezzamenti
def radice_dim(x:float) -> float:
    eps:float = .0000001 
    x1:float = 0.
    x2:float = x
    while (x2-x1) > eps:
        xm:float = (x1+x2)/2
        if xm*xm < x:
            x1 = xm
        else:
            x2 = xm
    return xm


# calcolo della radice di a - metodo babilonese
def radice_bab(a:float) -> float:
    x:float = 1 
    for _ in range(10): #10 iterazioni
        x = 1/2*(x+a/x)
    return x


# calcolo della radice di 2 mediante frazione continua [1,2,2,2,2]
# eseguendo n iterazioni - VERSIONE ALTERNATIVA
def radice2fc(n:int) -> float:
    x:float = 2   
    for _ in range(n):
        x = 2+1/x
    return x-1


# calcolo della radice di 2 mediante frazione approssimatrice
# eseguendo k iterazioni 
# equivale al metodo radice_bab sopra
# 
def radice2fa(k:int) -> float:
    m = 3
    n = 2
    x:float = m/n
    for _ in range(k):
        p = m
        q = n
        m = p*p+2*q*q
        n = 2*p*q
        x = m/n
    return x

#=============================
clear()

r = radice_bab(2)
print('radbab(2) = ',r)
     
r = radice2fc(15)
print('radfc(2) = ',r)
   
r = radice2fa(10)
print('radfa(2) = ',r)
  

		
