#-----------------------------------------------
# File: succb.tm - <TMachine>
# Data: 22 apr 26
# Note: computazione del successivo di un numero
#       espresso in notazione binaria
#
# Alfabeto = {0,1}
# Stati possibili = {0,1,2,H}
# Stato iniziale = 0
# Stati Finali = {H}

# nastro iniziale
#start 10100[0]11111
start 10101111

# posizionamento sul carattere piu' a destra
0,0,0,0,>
0,1,0,1,>
0,_,1,_,<

# computazione del successivo
1,0,H,1,-
1,1,1,0,<
1,_,H,1,-

# posizionamento sul carattere piu' a sinistra (per default)
#2,0,2,0,<
#2,1,2,1,<
#2,_,H,_,>

# esecuzione ciclica
# (senza le seguenti due quintuple la TM si ferma)
#H,1,0,1,-
#H,0,0,0,-









