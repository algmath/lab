#File: doppio10.mdt
#Date: 22 apr 26
#Note: calcolo del doppio di un numero in notazione decimale - ok

#spostamento a destra
0,0,0,0,>
0,1,0,1,>
0,2,0,2,>
0,3,0,3,>
0,4,0,4,>
0,5,0,5,>
0,6,0,6,>
0,7,0,7,>
0,8,0,8,>
0,9,0,9,>
0,_,1,_,<

#calcolo del doppio da destra a sinistra
#in stato di riporto
1,_,H,_,>
1,0,1,0,<
1,1,1,2,<
1,2,1,4,<
1,3,1,6,<
1,4,1,8,<
1,5,2,0,<
1,6,2,2,<
1,7,2,4,<
1,8,2,6,<
1,9,2,8,<

2,_,H,1,-
2,0,1,1,<
2,1,1,3,<
2,2,1,5,<
2,3,1,7,<
2,4,1,9,<
2,5,2,1,<
2,6,2,3,<
2,7,2,5,<
2,8,2,7,<
2,9,2,9,<








