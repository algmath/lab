#-----------------------------------------------
# File: castor3.tm - <TMachine> 
# Date: 22 apr 26
# Note: alacre castoro a 3 stati (escluso stato finale)
#       scrive 6 * partendo con nastro vuoto 
#
# Alfabeto = {*}
# Stati possibili = {0,1,2,3,H}
# Stato iniziale = 0
# Stati finali = {H}

start   #nastro vuoto

0,_,1,*,> 
0,*,2,*,<
1,_,0,*,<
1,*,1,*,>
2,_,1,*,<
2,*,H,*,-




