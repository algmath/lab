#-----------------------------------------------
# File: binary2unary.tm - ok 
# Data: 22 apr 26 
# Note: conversione di un numero da notazione binaria a unaria 
#       ci possono essere leading zeros (es.: 000101)
     
start 101
 
#analizza la prima cifra binaria a sx
0,1,2,U,>
0,0,2,_,>
0,U,T,_,>
0,|,K,|,<
0,_,K,_,-

#aggiungi | in coda [1]
1,0,1,0,>
1,1,1,1,>
1,|,1,|,>
1,_,4,|,<

# duplica i | in coda [2]
2,0,2,0,>
2,1,2,1,>
2,_,4,_,<
2,|,D0,|,>  #inizio duplicazione
 
#----- duplicazione | ----
# vai sull'ultimo | a destra 
D0,|,D0,|,>
D0,+,D1,+,>
D0,_,D1,_,<

# cambia il | corrente in +
D1,|,D2,+,>
 
# accoda un + a destra
D2,+,D2,+,>
D2,_,D3,+,<

# vai a sinistra finche' trovi | e cambialo in +
D3,+,D3,+,<
D3,|,D1,|,-    
D3,_,D4,_,>
D3,0,D4,0,>
D3,1,D4,1,>
D3,U,D4,U,>

# cambia tutti i + in |
D4,+,D4,|,>
D4,_,4,_,<

#torna sulla prima cifra binaria a sx
4,|,4,|,<
4,0,4,0,<
4,1,4,1,<
4,U,4,U,<
4,_,0,_,>

#aggiunta di | in coda 
T,0,T,0,>
T,1,T,1,>
T,|,T,|,>
T,_,4,|,-

#aggiunta di | in testa (| aggiuntivo per notazione unaria)
K,_,H,|,-






