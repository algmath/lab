# File: triangolopedale.py - <PyPen>
# Date: 27 apr 26
# Note: costruzione di un triangolo pedale di un dato triangolo

from costruzioni import *  

# input di un triangolo;
# ritorna la lista dei punti acquisiti in input
# vengono impostati gli attributi attuali (colore, stato, ...)
def input_triangolo(vertices=['','','']) -> list :
    A = Point(INPUT,state=DRAGGABLE,name=vertices[0]) 
    B = Point(INPUT,node=A,state=DRAGGABLE,name=vertices[1])
    s = Segment(A,B,state=DRAGGABLE) 
    C = Point(INPUT,node=(A,B),state=DRAGGABLE,name=vertices[2])
    Segment(B,C,state=DRAGGABLE)
    Segment(C,A,state=DRAGGABLE)
    return [A,B,C]

# triangolo pedale del punto P rispetto al triangolo ABC
def triangolopedale(P:Point,A:Point,B:Point,C:Point) -> tuple :
    R = piede(P,Line(A,B,color='grey',width=THIN)).config(color='orange')
    S = piede(P,Line(B,C,color='grey',width=THIN)).config(color='orange')
    T = piede(P,Line(A,C,color='grey',width=THIN)).config(color='orange')
    return [R,S,T]

#=============================
clear()
message('seleziona i 3 vertici del triangolo ...')

''' 
A = Point(INPUT,name='A',color='red',state=DRAGABLE)
B = Point(INPUT,name='B',color='red',state=DRAGABLE)
C = Point(INPUT,name='C',color='red',state=DRAGABLE) 
Segment(A,B,color='red',state=VISIBLE,width=MEDIUM)
Segment(A,C,color='red',state=VISIBLE,width=MEDIUM)
Segment(B,C,color='red',state=VISIBLE,width=MEDIUM)
message('')
Segment(A,B)
Segment(A,C)
Segment(B,C)
'''

A, B, C = input_triangolo(vertices=['A','B','C'])

message('seleziona il punto P per costruire il triangolo pedale ...') 
P = Point(INPUT,name='P',color='red',state=DRAGGABLE)
message('')
tp = triangolopedale(P,A,B,C)
Segment(tp[0],tp[1],color='green',state=VISIBLE,width=MEDIUM)
Segment(tp[0],tp[2],color='green',state=VISIBLE,width=MEDIUM)
Segment(tp[1],tp[2],color='green',state=VISIBLE,width=MEDIUM)




    

   
