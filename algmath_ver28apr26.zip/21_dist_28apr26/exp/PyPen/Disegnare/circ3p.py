# File: circ3p.py - ok
# Date: 21 feb 26 
# Note: circonferenza passante per 3 dati punti
#       applicazione <PyPen>

_cons_color = 'gray' # colore delle linee di costruzione

# asse di un segmento
# cfr. Alg.153, pag. 499
def asseg(s:Segment) -> Line:
    global _cons_color
    A = head(s)
    B = tail(s)
    a = Circle(A,B,color=_cons_color,state=VISIBLE,width=THIN)
    b = Circle(B,A,color=_cons_color,state=VISIBLE,width=THIN)
    P, Q = inters(a,b)
    return Line(P,Q)

# asse di un segmento dato dai 2 estremi
# cfr. Alg.153, pag. 499
def asse2p(A:Point,B:Point) -> Line:
    global _cons_color
    a = Circle(A,B,color=_cons_color,state=VISIBLE,width=THIN)
    b = Circle(B,A,color=_cons_color,state=VISIBLE,width=THIN)
    P, Q = inters(a,b)
    return Line(P,Q)


# circonferenza per 3 punti 
def circolo(A:Point,B:Point,C:Point) -> Circle:  
    '''
    s1 = Segment(A,B,color=_cons_color,state=VISIBLE,width=THIN)
    s2 = Segment(B,C,color=_cons_color,state=VISIBLE,width=THIN)
    a1 = asseg(s1).config(color=_cons_color,state=VISIBLE,width=THIN)
    a2 = asseg(s2).config(color=_cons_color,state=VISIBLE,width=THIN)
    '''

    a1 = asse2p(A,B).config(color=_cons_color,state=VISIBLE,width=THIN)
    a2 = asse2p(B,C).config(color=_cons_color,state=VISIBLE,width=THIN)
    
    C = inters(a1,a2)
    #return Circle(C,dist(C,A))
    return Circle(C,A)

#---- main ----
clear()
mes = "seleziona primo punto ..."
P1 = Point(INPUT,msg=mes,color='blue',state=DRAGGABLE)
mes = "seleziona secondo punto ..."
P2 = Point(INPUT,msg=mes,color='blue',state=DRAGGABLE)
mes = "seleziona terzo punto ..."
P3 = Point(INPUT,msg=mes,color='blue',state=DRAGGABLE)
c = circolo(P1,P2,P3)
c.config(name='c',color='red',state=ACTIVE)
