# File: centro_con_compasso.py - ok
# Date: 22 apr 26
# Note: centro circonf. usando solo compasso
#       cfr. M.Gardner, Circo Matematico, p. 248
#       [problema di Napoleone]

# centro circ. alfa usandolo solo il compasso
def centro(a:Circle) -> Point:
    A = Point(RANDOM,on=a,name='A',color='green',state=DRAGGABLE)
    B = Point(RANDOM,on=a,name='B',color='green',state=DRAGGABLE)
    #A.config(color='green',state=VISIBLE)
    #B.config(color='green',state=VISIBLE)
    b = Circle(A,B).config(color='orange',width=THIN,state=VISIBLE)
    X, Y = inters(a,b)
    C = CondPoint(X==B,Y,X)
    C.config(color='black',state=VISIBLE)
    #return C #provvisorio
    c = Circle(B,A).config(color='orange',width=THIN,state=VISIBLE)
    d = Circle(C,A).config(color='orange',width=THIN,state=VISIBLE)
    #return A #provvisorio
    X, Y = inters(c,d)
    D = CondPoint(X!=A,X,Y) #punto condizionale
    D.config(name='D',color='blue',state=VISIBLE)
    #return D #provvisorio
    e = Circle(D,A).config(color='red',width=THIN,state=VISIBLE)
    E, F = inters(e,b)
    E.config(name='E',color='orange',state=VISIBLE)
    F.config(name='F',color='orange',state=VISIBLE)
    #return D #provvisorio
    h = Circle(E,A).config(color='gray',width=THIN,state=VISIBLE)
    k = Circle(F,A).config(color='gray',width=THIN,state=VISIBLE)
    X, Y = inters(h,k)
    R = CondPoint(X==A,Y,X)
        
    return R
  

#---- main ----
clear()
a = Circle(INPUT,color='blue',state=DRAGGABLE,width=MEDIUM)
C = centro(a)
C.config(color='red',state=VISIBLE)

#t = Segment(N,T,color='green',state=VISIBLE,width=MEDIUM)
show('C=',C)


