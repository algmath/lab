# File: colleg_min.py - ok
# Date: 2 feb 26 
# Note: collegamento minimo Punto-Retta-Punto 
#       (anche come test per oggetti condizionali)
#       usare in configurazione <PyPen>

#sys.path.append('../exp/lib')  #RIM
from costruzioni import * #piede 

clear()
setgrid(True)

s = 'seleziona una retta ...'
#r = Line(INPUT,msg=s,name='r',color='blue',state=VISIBLE)
r = Line(INPUT,msg=s,name='r',color='blue',state=DRAGGABLE)
s = 'seleziona un punto ...'
P = Point(INPUT,msg=s,name='P',color='blue',state=DRAGGABLE)
s = 'seleziona un altro punto ...'
Q = Point(INPUT,msg=s,name='Q',color='blue',state=DRAGGABLE)

#S = speculare(P,Q,r).config(color='red',name='S',width=3,state=VISIBLE)
K = hom(Q,piede(Q,r),2) #speculare di Q rispetto a r - usare simm
#K.config(name='K',width=3,color='brown',state=VISIBLE) #inibire il width=3

K.config(name='K',color='brown',state=VISIBLE)

stessaparte = dist(P,Q)<dist(P,K) #e' DataObject (True,False)
display('stessaparte=',stessaparte)
#print('stessaparte =',stessaparte)
s = Line(P,K,width=1,color='blue',name='s',state=ATTACHABLE)
display('s=',s)

M = Intersection(r,s,name='M',color='brown',state=ATTACHABLE)
#M = Intersection(r,s,name='M',color='brown',state=DRAGABLE)

#T = M if stessaparte else P # NON COSI': T deve essere dinamico
T = IfPoint(stessaparte,M,P) #punto condizionale  ok 26gen23
d1 = dist(T,M)
d2 = T.dist(M)

display('d1=',d1)
display('d2=',d2)
display('M=',M) 
display('P=',P)
display('Q=',Q)
display('T=',T)

#s1 = Segment(P,T,width=2,color='red',state=VISIBLE)
#s1 = Segment(P,T,color='red',state=VISIBLE)
s1 = Segment(P,T,color='red',width=3,state=ACTIVE)
display('s1=',s1)   
#s2 = Segment(T,Q,color='red',state=VISIBLE)
s2 = Segment(T,Q,color='red',width=3,state=ACTIVE)

setmode(DRAG)

