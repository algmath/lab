# File: tangenti2circ.py - <PyPen>
# Date: 2 feb 26 
# Note: tangenti esterne a 2 circonferenze

#sys.path.append('../prog/lib') #oppure da mettere in initg.py

#from gwinter import * #prova del 19gen26   NON QUI
from costruzioni import * 

clear()
mes = 'seleziona una circonferenza ...'
c1 = Circle(INPUT,msg=mes,color='blue',name='c1',state=ACTIVE)
display('circ c1 = ',c1)  
c2 = Circle(INPUT,msg=mes,color='blue',name='c2',state=ACTIVE)
display('circ c2 = ',c2) 
C1 = center(c1)
C2 = center(c2)
r1 = radius(c1)
r2 = radius(c2)
display('C1 = ',center(c1))
display('C2 = ',center(c2))
display('radius c1 = ',r1)
display('radius c2 = ',r2)
d = dist(C1,C2)
x = (r1*d)/(r2-r1)
display('x = ',x)
#P = oltre(C2,C1,x)  #ok
P = hom(C2,C1,1+x*~dist(C1,C2))   # ~ e' l'inverso (alla -1)
P.config(color='red',state=ACTIVE)
display('P = ',P)
S, T = tangenti(c1,P)
t1 = Line(P,S,color='blue',state=ATTACHABLE)
t2 = Line(P,T,color='blue',state=ATTACHABLE)
t1.config(color='red',state=ACTIVE)
t2.config(color='red',state=ACTIVE)



