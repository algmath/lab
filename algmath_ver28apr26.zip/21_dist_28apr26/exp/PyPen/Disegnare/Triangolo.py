# File: Triangolo.py - <PyPen>
# Date: 27 apr 26
# Note: classe dei triangoli

import sys
sys.path.append('../exp/lib')
from costruzioni import *  

class Triangolo:
    "triangolo individuato dai 3 vertici"

    # triangolo di 3 dati vertici
    def __init__(self, A:Point, B:Point, C:Point):
        self._a = A
        self._b = B
        self._c = C

    # input di un triangolo in modalita' rubberbanding
    def __init__(self,vertices=('','',''),color='brown',state=DRAGGABLE,width=MEDIUM):
        A = Point(INPUT,state=state,name=vertices[0]) 
        B = Point(INPUT,node=A,state=state,name=vertices[1])
        s = Segment(A,B,state=state,color=color,width=width) 
        C = Point(INPUT,node=(A,B),state=state,name=vertices[2])
        Segment(B,C,state=state,color=color,width=width)
        Segment(C,A,state=state,color=color,width=width)
        
        self._a = A
        self._b = B
        self._c = C

    def perimetro(self):
        return dist(self._a,self._b)+dist(self._b,self._c)+dist(self._c,self._a)
       

#-- funzioni --

def fperimetro(t:Triangolo):
    return dist(t._a,t._b)+dist(t._b,t._c)+dist(t._c,t._a)

#formula di Erone
def earea(t:Triangolo) -> float:
    a = dist(t._b,t._c)
    b = dist(t._a,t._c)
    c = dist(t._a,t._b)
    p = (a+b+c)/2
    #ris = math.sqrt(p*(p-a)*(p-b)*(p-c))
    ris = (p*(p-a)*(p-b)*(p-c)).sqrt()
    return ris

#formula di geometria analitica
def area(t:Triangolo) -> float:
    xa = getx(t._a)
    ya = gety(t._a)
    xb = getx(t._b)
    yb = gety(t._b)
    xc = getx(t._c)
    yc = gety(t._c)
    area = xa*yb + xb*yc + xc*ya - xa*yc - xb*ya  - xc*yb
    return area/2
    
def circcirc(t:Triangolo) -> Circle:
    a1 = asse(t._a,t._b)
    a2 = asse(t._b,t._c)
    C = inters(a1,a2)
    r = dist(C,t._a)
    return Circle(C,r)

# incentro: punto di incontro delle bisettrici
# e' anche il centro della circonferenza inscritta
def incentro(t:Triangolo) -> Point:  
    alfa = dist(t._a,t._b)/((dist(t._a,t._b)+dist(t._a,t._c))) 
    K = hom(t._b,t._c,alfa) #.config(name='K',color='red',state=DRAGABLE)  
    beta = dist(t._b,t._a)/((dist(t._b,t._a)+dist(t._b,t._c)))  
    L = hom(t._a,t._c,beta) #.config(name='L',color='red',state=VISIBLE) 
    b1 = Line(t._a,K).config(state=VISIBLE,color='orange',width=THIN)
    b2 = Line(t._b,L).config(state=VISIBLE,color='orange',width=THIN)
    I = inters(b1,b2).config(state=VISIBLE,color='red')
    return I 

#circonferenza inscritta in un triangolo
def circinscr(t:Triangolo) -> Circle:
    I = incentro(t)
    r = Line(t._a,t._b) #,state=INVISIBLE,color='green')
    P = piede(I,r)
    return Circle(I,P) 
    
#circonferenza circoscritta ad un triangolo
def circcirc(t:Triangolo) -> Circle:
    a1 = asse(t._a,t._b) 
    a2 = asse(t._a,t._c) 
    C = inters(a1,a2)
    return Circle(C,t._a) 

 



    

   
