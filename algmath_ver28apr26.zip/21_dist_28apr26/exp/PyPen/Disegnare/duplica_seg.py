# File: duplica_seg.py - <PyPen> 
# Date: 27 apr 26
# Note: duplicazione segmento usando solo il compasso
#       cfr. alg nel cap. Tracciare

# duplica il segmento AB, ritornando il secondo estremo
def duplica_seg(A:Point,B:Point) -> Point:
    alfa = Circle(A,B).config(color='gray',state=VISIBLE,width=THIN)
    beta = Circle(B,A).config(color='gray',state=VISIBLE,width=THIN)
    C, D = inters(alfa,beta)
    gamma = Circle(C,D).config(color='gray',state=VISIBLE,width=THIN)
    delta = Circle(D,C).config(color='gray',state=VISIBLE,width=THIN)
    F, _ = inters(gamma,delta)
    return F

# duplica il segmento AB, ritornando il secondo estremo - ver.2
def duplica_seg2(A:Point,B:Point) -> Point:
    alfa = Circle(A,B)
    beta = Circle(B,A)
    C, _ = inters(alfa,beta)
    gamma = Circle(C,B)
    D, _ = inters(gamma,beta)
    delta = Circle(D,B)
    F, _ = inters(delta,beta)
    return F

#---- main ----
clear()
s = Segment(INPUT,color='red',state=DRAGGABLE,width=MEDIUM)
M = head(s)
N = tail(s)
#T = duplica_seg(M,N)  #ok
T = duplica_seg2(M,N)  #ok
T.config(color='green',state=VISIBLE)
t = Segment(N,T,color='green',state=VISIBLE,width=MEDIUM)
display('T=',T)


