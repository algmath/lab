# File: punto_quadranti.py - <PyPen>
# Date: 27 apr 26
# Note: punto che cambia colore a seconda del quadrante

clear()

A = Point(3,4,name='A',color='black',state=DRAGGABLE)
c1 = andv(getx(A)>=0,gety(A)>=0) #I quadrante
c2 = andv(getx(A)<0,gety(A)>=0)  #II quadrante
c3 = andv(getx(A)<0,gety(A)<0)   #III quadrante
c4 = andv(getx(A)>=0,gety(A)<0)  #IV quadrante
col = IfValue(c1,'red',IfValue(c2,'blue',IfValue(c3,'green4','black')))
A.config(color=col)

display('c1=',c1)
display('c2=',c2)
display('c3=',c3)
display('c4=',c4)
display('col=',col)

