# File: pentagono.py - <PyPen> - ok, ma molto lento
# Date: 22 feb 26
# Note: pentagono inscritto in una circonferenza

from costruzioni import *

#---- main ----

clear()

#a = Circle(Point(2,3),2,color='blue',state=DRAGABLE,width=MEDIUM)

#versione molto lenta in drag
#a = Circle(INPUT,color='blue',state=DRAGABLE,width=MEDIUM)
#C = centro(a).config(name='C',color='brown',state=VISIBLE,width=MEDIUM)
#A = Point(RANDOM,on=a,color='green',state=VISIBLE,width=THIN)

#versione lenta in drag
C = Point(INPUT,name='C',color='blue',state=DRAGGABLE)
A = Point(INPUT,name='A',color='blue',state=DRAGGABLE)
a = Circle(C,A,color='blue',state=VISIBLE)
r = Line(A,C).config(color='orange',state=VISIBLE,width=THIN)
A,B = inters(r,a)
A#.config(name='A',color="gray",state=VISIBLE)
B#.config(name='B',color="gray",state=VISIBLE)
s = perp(C,r)#.config(color='orange',state=VISIBLE,width=THIN)
E = medio(A,C)#.config(name='E',color="gray",state=VISIBLE)
D,D = inters(s,a)
D#.config(name='D',color="red",state=VISIBLE)
b = Circle(E,D)#.config(name='b',color='red',state=VISIBLE,width=THIN)
X, Y = inters(b,r)
F = IfPoint(dist(X,C)<dist(Y,C),X,Y)
F.config(name='F',color="black",state=VISIBLE)
c = Circle(D,F,color='green',state=VISIBLE,width=THIN)
I,J = inters(c,a)
I.config(name='I',color='red',state=VISIBLE)
J.config(name='J',color='red',state=VISIBLE)
d = Circle(I,D,color='green',state=VISIBLE,width=THIN)
X, Y = inters(a,d)
H = IfPoint(X!=D,X,Y)
H.config(name='H',color='red',state=VISIBLE)
e = Circle(J,D,color='green',state=VISIBLE,width=THIN)
X, Y = inters(a,e)
K = IfPoint(X!=D,X,Y)
K.config(name='K',color='red',state=VISIBLE)
Segment(D,I,color='red',state=VISIBLE,width=THICK)
Segment(I,H,color='red',state=VISIBLE,width=THICK)
Segment(H,K,color='red',state=VISIBLE,width=THICK)
Segment(K,J,color='red',state=VISIBLE,width=THICK)
Segment(J,D,color='red',state=VISIBLE,width=THICK)



