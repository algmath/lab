# File: compmolle.py - <PyPen>
# Date: 27 apr 26
# Note: problema del compasso molle

# circonferenza di centro C e raggio AB 
# usando solo il compasso molle
def circompmolle(C:Point, A:Point, B:Point) -> Circle:
    alfa = Circle(A,C).config(name='a',state=DRAGGABLE,width=1,color='black')
    beta = Circle(C,A).config(name='b',state=DRAGGABLE,width=1,color='blue')
    D, E = inters(alfa,beta)
    delta = Circle(D,B).config(name='d',state=DRAGGABLE,width=1,color='brown')
    eta = Circle(E,B).config(name='e',state=DRAGGABLE,width=1,color='gray')
    H,K = inters(delta,eta)
    q = dist(A,B)==dist(C,H) 
    display('Q=',q)
    T = IfPoint(q,H,K)  # punto condizionale 
    gamma = Circle(C,T).config(name='c',state=DRAGGABLE,width=1,color='red')
    return gamma

#-- problema del compasso molle -- 
clear()
mess = 'seleziona il segmento-raggio della circonferenza...'
s = Segment(INPUT,msg=mess,name='s',color='orange',state=DRAGGABLE)
A = head(s)
A.config(name='A',state=DRAGGABLE,color='green')
B = tail(s)
B.config(name='B',state=DRAGGABLE,color='green')
mess = 'seleziona il centro della circonferenza...'
C = Point(INPUT,msg=mess,name='C',color='blue',state=DRAGGABLE)
alfa = circompmolle(C,A,B) 
alfa.config(color='red',state=DRAGGABLE,width=MEDIUM) #,expand=False)

