# File: punto_medio_compasso.py - <PyPen> 
# Date: 27 apr 26
# Note: punto medio segmento usando solo il compasso
#       cfr. alg nel cap. Disegnare

# punto medio fra A e B
def medio2(A:Point,B:Point) -> Point:
    alfa = Circle(A,B)
    beta = Circle(B,A)
    C, _ = inters(alfa,beta)
    gamma = Circle(C,A)
    X, Y = inters(gamma,beta)
    D = IfPoint(X==A,Y,X)
    D.config(name='D',color='black',state=VISIBLE)
    delta = Circle(D,C)
    X, Y = inters(delta,beta)
    E = IfPoint(X==C,Y,X)
    E.config(name='E',color='brown',state=VISIBLE)
    eta = Circle(E,A)
    F, G = inters(eta,alfa)
    zeta = Circle(F,A)
    theta = Circle(G,A)
    X, Y = inters(zeta,theta)
    M = IfPoint(X==A,Y,X)

    alfa.config(color='orange',state=VISIBLE,width=THIN)  
    beta.config(color='orange',state=VISIBLE,width=THIN)  
    gamma.config(color='orange',state=VISIBLE,width=THIN)  
    delta.config(color='orange',state=VISIBLE,width=THIN)  
    eta.config(color='orange',state=VISIBLE,width=THIN)  
    theta.config(color='orange',state=VISIBLE,width=THIN)  
    zeta.config(color='orange',state=VISIBLE,width=THIN)  #
       
    return M

#---- main ----
clear()
#s = Segment(INPUT,color='red',state=DRAGABLE,width=MEDIUM)
#A = head(s)
#B = tail(s)
A = Point(INPUT,msg='A?',name='A',color='red',state=DRAGGABLE)
B = Point(INPUT,msg='B?',name='B',color='red',state=DRAGGABLE)
M = medio2(A,B)  
M.config(name='M',color='green',state=VISIBLE)
display('M=',M)


