# File: movimenti.py - <PyPen> - ok
# Date: 22 feb 26 
# Note: movimento automatico del centro di un circle

from time import sleep

clear()

P = Point((1,2),color='red',state=DRAGGABLE)
Q = Point((-1,-1),color='green',state=DRAGGABLE)
P.config(color='brown')
s = Segment(P,Q,color='orange',name='s',state=DRAGGABLE)
print('COORDINATE DI P: ',coordsvalues(P))
#drag(P,-50,15)
setxy(P,3,4)

print('sto iniziando a muovere')

c = Circle(P,dist(P,Q)/4).config(state=DRAGGABLE,color='orange')
#c = Circle(P,2).config(state=DRAGGABLE,color='orange')

#Circle(INPUT,msg='seleziona una circonferenza...')
#Segment(INPUT,msg='seleziona un segmento...')

#movimento
for i in range(100):
    sleep(0.005) #100ms
    k = i/20
    setxy(P,3+k*k-4*k,4-k*k+k)
    sleep(0.02) #sec
    #P._update()
    update() #definita in gwinter.py

print('NUOVE COORDINATE: ',coordsvalues(P))
