# File: tangenti.py - <PyPen>
# Date: 27 apr 26 
# Note: tangenti esterne ad una circonferenza per un punto

from costruzioni import * #presente nell'area \lib 

clear()

'''
#tangenti esterne ad una circonferenza per un punto [metodo 1] - ok 15mar25
mes = 'seleziona una circonferenza...'
a = Circle(INPUT,msg=mes,color='blue',name='a',state=DRAGGABLE)
display('circ a = ',a)  
C = center(a)
mes = 'seleziona un punto esterno ...'
P = Point(INPUT,msg=mes,color='blue',name='P',state=DRAGGABLE)
M = med(P,C).config(name='M',state=DRAGGABLE)
D = pointOn(a)
#S,T = cxc(M,P,C,D)  #ok
#S,T = inters(Circle(M,P),Circle(C,D))  #ok
c1 = Circle(M,P).config(state=VISIBLE,color='gray',width=THIN)
#c2 = Circle(C,D).config(state=VISIBLE,color='gray')
S,T = inters(c1,a)  #ok
S.config(color='orange',state=VISIBLE)
T.config(color='orange',state=VISIBLE)
Line(P,S,color='orange',state=VISIBLE)
Line(P,T,color='orange',state=VISIBLE)
'''


#'''
#-- tangenti ad una circ condotte da un punto esterno [metodo 2] -- ok 17lug24
s = 'seleziona una circonferenza ...'
c = Circle(INPUT,msg=s,color='red',width=MEDIUM,state=DRAGGABLE)
s = 'seleziona un punto esterno ...'
P = Point(INPUT,msg=s,name='P',color='red',state=DRAGGABLE)
S,T = tangenti(c,P)  #nel modulo costruzioni
S.config(color='green',state=VISIBLE)
T.config(color='green',state=VISIBLE)
#t1 = Line(P,S,color='blue',state=VISIBLE)
#t2 = Line(P,T,color='blue',state=VISIBLE)
t1 = Line(P,S,color='blue',state=ACTIVE)
t2 = Line(P,T,color='blue',state=ACTIVE)
display('t1 = ',t1)
display('t2 = ',t2)
#setmode(const._DRAG)  #non visibile
#'''



