# File: dist_min.py - <PyPen>
# Date: 27 apr 26
# Note: il punto P dinamicamente si collega al piu' vicino fra A, B e C
#       P non cambia colore spostando A,B,C 

clear()

A = Point(2,3,name='A',color='blue',state=DRAGGABLE)
B = Point(1,2,name='B',color='red',state=DRAGGABLE)
C = Point(4,1,name='C',color='green4',state=DRAGGABLE)
P = Point(3,4,name='P',color='black',state=DRAGGABLE)

condA = andv(dist(P,A)<=dist(P,B),dist(P,A)<dist(P,C))
condB = andv(dist(P,B)<=dist(P,A),dist(P,B)<dist(P,C))
#Q = IfPoint(cond,A,B)  #ok per i 2 pti A e B
Q = IfPoint(condA,A,IfPoint(condB,B,C))
col = Q.getcolor()  
P.config(color=col)  #cambia colore dinamicamente come Q

x = Segment(P,Q,color=col,state=DRAGGABLE,width=MEDIUM)
Label(x,"dist={0}",[dist(P,Q)],color=col,offset=(5,0))  #ok

