# File: thue-morse.py - ok
# Date: 6 mar 24
# Note: conversione binario-> unario usando i sistemi di riscrittura

'''
Conversione con gli algoritmi di Markov:

Another Example
These rules give a more interesting example.
They rewrite binary numbers to their unary counterparts.
For example, 101 will be rewritten to a string of 5 consecutive bars.

Rules
"|0" -> "0||"
"1" -> "0|"
"0" -> ""
Symbol string
"101"

Execution
If the algorithm is applied to the above example, it will terminate after the following steps.

"101"
"0|01"
"00||1"
"00||0|"
"00|0|||"
"000|||||"
"00|||||"
"0|||||"
"|||||"
'''



#from lsistemi import *  #contiene il sostituisci sotto

# sostituzione mediante la tecnica dei sistemi di riscrittura
# degli algoritmi di Markov
'''
def sostituisci(assioma:str,regole:dict,niter:int) -> str:
    if not regole is None:
        for i in range(niter):
            ris = ""
            for c in assioma:
                ris = ris + regole.get(c,c) #get: se non c'e' c ritorna c
            assioma = ris
    return assioma
'''
def sostituisci(assioma:str,regole:dict) -> str:
    if not regole is None:
        for i in range(niter):
            ris = ""
            for c in assioma:
                ris = ris + regole.get(c,c) #get: se non c'e' c ritorna c
            assioma = ris
    return assioma

#assioma = '0'
#regole = {'0':'01','1':'10'}  #..
assioma = '11'
#regole = {'|0':'0||','1':'0|','0':''}  # ok
regole = {'|0':'0||','1':'0|','0':''}  #..


#for k in iter(regole):
#    print("chiave =",k,"valore =",regole[k])

ciclo = True
while ciclo:
    trovato = False
    for k in iter(regole):
        if not trovato:
            #print("chiave =",k,"valore =",regole[k])
            ris = regole.get(k) #ritorna None se non trova nel dizionario
            if not ris is None:
                #print("trovata chiave =",k,"valore =",regole[k])
                if assioma.find(k) != -1:
                    #print("trovata chiave =",k,"valore =",regole[k])
                    trovato = True
                    assioma = assioma.replace(k,ris,1)
                    #print('NUOVO ASSIOMA =',assioma)
    if not trovato: ciclo = False
    xprint('ASSIOMA FINE CICLO =',assioma,'    TROVATO =',trovato)

print('ASSIOMA FINALE =',assioma)
    
'''
s = '1'  #
ris = regole.get('|0') #ritorna None se non trova nel dizionario
if not ris is None:
    assioma = assioma.replace(s,ris,1)
    print('RIS e ASSIOMA dopo sostituzione: RIS =',ris,'    ASSIOMA =',assioma)
'''


''' RIM
for k in range(4):
    stringa = sostituisci(assioma,regole,k)
    #write("stringa="+stringa)
    print("stringa=",stringa)
disegno = stringa #ultima generata
print('disegno =',disegno)
'''

