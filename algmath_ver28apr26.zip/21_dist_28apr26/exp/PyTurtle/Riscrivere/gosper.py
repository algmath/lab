# File: gosper.py - ok
# Date: 6 gen 26
# Note: curva esagonale di Gosper - <PyTurtle>

assioma = 'X'
regole = {'X':'X+YF++YF-FX--FXFX-YF+','Y':'-FX+YFYF++YF+FX--FX-Y'}
disegno = sostituisci(assioma,regole,3)  
#print("D=",disegno)
angolo, passo = 60, .5  
hide() #per velocizzare il disegno
setcolor('black')
init()
disegna(disegno,angolo,passo)
