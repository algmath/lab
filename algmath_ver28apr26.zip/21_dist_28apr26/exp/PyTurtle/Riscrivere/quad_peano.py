# File: quad_peano - ok
# Date: 6 gen 26
# Note: quadrati di Peano - <PyTurtle>

from lsistemi import *

assioma = 'X'
regole = {'X':'F-F-F-F','F':'F-F+F+F+F-F-F-F+F'}  # [1] ?
disegno = sostituisci(assioma,regole,3)  
#print("D=",disegno)
angolo, passo = 90, .5
init()
hide() #per velocizzare il disegno
setcolor('black')
disegna(disegno,angolo,passo)
