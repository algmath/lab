# File: stella6 - ok
# Date: 6 feb 26
# Note: stella esagonale - <PyTurtle>

from lsistemi import *

assioma = 'X'
regole = {'X':'[F+F++F]+X'}

#disegno = sostituisci(assioma,regole,6)  
#print("D=",disegno)

angolo, passo = 60, 1   
hide() #per velocizzare il disegno
setcolor('black')
init()
#disegna(disegno,angolo,passo)
sost_disegna(assioma,regole,niter=6,ang=angolo,passo=passo)
