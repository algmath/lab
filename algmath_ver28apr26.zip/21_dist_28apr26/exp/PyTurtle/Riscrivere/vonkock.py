# File: vonkock - ok
# Date: 7 feb 26
# Note: curva di von Kock - <PyTurtle>

from lsistemi import *

assioma = 'F'
regole = {'F':'F-F++F-F'}

#fiocco
assioma = 'X'
regole = {'X':'F++F++F','F':'F-F++F-F'} #esterno
regole = {'X':'F++F++F','F':'F+F--F+F'} #interno: alla Mitsubishi

disegno = sostituisci(assioma,regole,4)
#print("D=",disegno)
angolo, passo = 60, .2
init()
right(90)
disegna(disegno,angolo,passo)
