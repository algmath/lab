# File: markov.py - ..
# Date: 4 feb 26
# Note: conversione binario-> unario usando i sistemi di riscrittura

'''
Conversione con gli algoritmi di Markov:

Another Example
These rules give a more interesting example.
They rewrite binary numbers to their unary counterparts.
For example, 101 will be rewritten to a string of 5 consecutive bars.

Rules
"|0" -> "0||"
"1" -> "0|"
"0" -> ""
Symbol string
"101"

Execution
If the algorithm is applied to the above example, it will terminate after the following steps.

"101"
"0|01"
"00||1"
"00||0|"
"00|0|||"
"000|||||"
"00|||||"
"0|||||"
"|||||"
'''

#from lsistemi import *  #contiene sostituisci

''' sostituzione per algoritmo di Markov:

Input: initial string s ∈ Σ*
While true:
    For each rule i from 1 to k in order:
        If α_i is a substring of s:
            Find the leftmost occurrence of α_i in s
            Replace it with β_i to form new s
            If rule i is terminal:
                Output s and halt
            Break to restart the while loop
    If no rule applied:
        Output s and halt

-----

They do text substitution with the following general rules applied to
a sequence of productions (a -> b):

if the sequence a is part of the current string, substitute the first occurrence with b;
always use the first applicable production;
repeat until a "halting" production (marked as ".") is executed

set productions {
    a0 -> 0a
    a1 -> 1b
    b0 -> 1a
    b1 -> 0b
    a  -> .
    b  -> .
    "" -> a
 }

---
Example 1 - MA for function f(x) = x / 2:

1. #|| -> |#
2. #| -> #|
3. # -> .
4. -> #

Input: ||||
Rule 4: |||| -> #||||
Rule 1: #|||| -> |#||
Rule 1: |#|| -> ||#
Rule 3: ||# -> ||
Output: ||

Note that the second rule handles the undefined case for the odd number
(x / 2 is not an integer for odd x).

---
Example 2 - MA for function f(x, y) = x + y

1. # ->

Input: ||||#||
Rule 1: ||||#|| -> ||||||
Output: ||||||
To add two numbers in unary system, we can simply remove the separator between them.

---------------

Example 3: Multiplication. MA3 = {Σ,P,P0}

Σ={a,A,B,C,#}

Productions in P
:
p1:Ba→aB
p2:Aa→aBA
p3:a→ϵ
p4:a#→#A
p5:#a→#
p6:#→ϵ
p7:B→a
p8:ϵ→⋅ϵ

P0={p8}


My question is about the above example. I understand the rules should be applied in linear order. So given an input of "aaa#aaa
", the first rule to match would be p3
, which says to replace a with the empty character. So the string will be consumed down to a single #, which is then also replaced with an empty character (p6
), then the machine halts with no output(p8
). How does this achieve multiplication? What am I not understanding?


Well, there is typo in that example. The substitution rule p3
 should have been
A→ϵ

In questo esempio, con input ||||#|||   (m| x n|) si ottiene come il risultato
il loro prodotto in unario (mn |)
        
'''



# algoritmo di Markov:
# trasformazione della stringa s in base alle regole
# argomeni:
#     s : stringa da elaborare
#     r : regole di sostotuzione
# ritorna: stringa elaborata
#
# il ciclo di sostituzione termina quando non si riesce piu' ad applicare
# alcuna regola oppure quando si applica una regola finale
# le regole (dizionario) eseguendo la sostituzione per niter volte;
# ritorna la stringa finale
# [break only stops the loop which it's in]
#
def alg_markov(s:str,r:dict) -> str:
    while True:
        #print('--- WHILE ---')
        ar = False #regola applicata
        for k in regole.keys():
            idx = s.find(k)
            if idx >= 0:
                s = s.replace(k,regole.get(k),1)
                ar = True
                #print('trovata regola ',k,'->',regole.get(k))
                print("s =",s)
                break #si termina alla prima regola applicata
        #se si e' applicata una regola finale (con '.') si elimina il '.' e si termina
        if regole.get(k).find('.')>=0:
            #print('trovata regola finale:',regole.get(k))
            s = s.replace('.','')  #eliminazione '.'
            break
        #se non si e' applicata alcuna regola si termina il ciclo while
        if not ar: break  
    #print('sto per ritornare')
    return s



#'''
#regole = {'|0':'0||','1':'0|','0':''}  #conversione binario->unario  ok, ma senza +|
#regole = {'|0':'0||','1':'0|','0':'','':'x'}  #conversione binario->unario  PROVA NO
regole = {'|0':'0||','1':'0|','0':'','':'.|'}  

s = '101'
r = alg_markov(s,regole)
#print('s elaborata =',s)
print(f'markov(\'{s}\') = {r}')
#'''

'''
#tests:               
idx = 'abc'.find('')
print('idx =',idx)

for k in regole.keys():
    print('chiave = ',k, 'val =',regole.get(k))

#idx = assioma.find('01')
idx = assioma.find('01x')
print('idx =',idx)

#assioma = assioma.replace('1','uno') #sostituisce entrambi gli 1
assioma = assioma.replace('1','uno',1) #sostituisce solo il primo 1
print('assioma =',assioma)

'''


