# File: sis_riscrittura.py - ok  CFR. thue-morse.py : uguali?
# Date: 3 feb 26
# Note: conversione binario-> unario usando i sistemi di riscrittura

from lsistemi import *  #contiene il sostituisci sotto

'''
# a partire dall'assioma (per ciascun suo carattere) vengono applicate
# le regole (dizionario) eseguendo la sostituzione per niter volte;
# ritorna la stringa finale
def sostituisci(assioma:str,regole:dict,niter:int) -> str:
    if not regole is None:
        for i in range(niter):
            ris = ""
            for c in assioma:
                ris = ris + regole.get(c,c) #get: se non c'e' c ritorna c
            assioma = ris
    return assioma
'''

#assioma = '0'
#regole = {'0':'01','1':'10'}  #..
assioma = '+'
regole = {'+':'+F','F':'F+'}  #..
for k in range(8):
    stringa = sostituisci(assioma,regole,k)
    #write("stringa="+stringa)
    #print("stringa=",stringa)


disegno = stringa #ultima generata
angolo, passo = 120, .2
init()
right(300)
disegna(disegno,angolo,passo)
#print('disegno =',disegno)

