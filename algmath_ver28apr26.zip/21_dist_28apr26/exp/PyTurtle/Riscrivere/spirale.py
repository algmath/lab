# File: spirale - ok
# Date: 6 gen 26
# Note: spirale quadrata - <PyTurtle>

from lsistemi import *

assioma = 'X'
regole = {'X':'XY+','Y':'YF'}
disegno = sostituisci(assioma,regole,16)
#print("D=",disegno)
angolo, passo = 90, .2
init()
disegna(disegno,angolo,passo)
