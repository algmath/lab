# File: hilbert.py - ok
# Date: 6 gen 26
# Note: curva di Hilbert - <PyTurtle>

from lsistemi import *

assioma = 'L'
regole = {'L':'+RF-LFL-FR+','R':'-LF+RFR+FL-'}
disegno = sostituisci(assioma,regole,4)  
#print("D=",disegno)
angolo, passo = 90, .3
hide() #per velocizzare il disegno
setcolor('black')

init()
disegna(disegno,angolo,passo)


