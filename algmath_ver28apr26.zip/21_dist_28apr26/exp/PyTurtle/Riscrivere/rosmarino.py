# File: rosmarino - ok
# Date: 6 gen 26
# Note: pianta di rosmarino <PyTurtle>

from lsistemi import *

assioma = 'F'
regole = {'F':'FF+[+F-F-F]-[-F+F+F]'}
disegno = sostituisci(assioma,regole,4)  
#print("D=",disegno)
angolo, passo = 20, .2

init()
hide() #per velocizzare il disegno
clear()
setcolor('green4')
disegna(disegno,angolo,passo)
