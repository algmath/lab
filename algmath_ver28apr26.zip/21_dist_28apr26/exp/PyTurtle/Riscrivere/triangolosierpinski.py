# File: triangolosierpinsky - ok
# Date: 6 gen 26
# Note: triangolo Sierpinsky - <PyTurtle>

from lsistemi import *

assioma = 'F+G+G'
regole = {'F':'F+G-F-G+F','G':'GG'}   
disegno = sostituisci(assioma,regole,4)
#print("D=",disegno)
angolo, passo = 120, .3
init()
right(30)
disegna(disegno,angolo,passo)
