# File: pentagoni - ok
# Date: 6 gen 26
# Note: pentagoni di pentagoni - <PyTurtle>

from lsistemi import *

assioma = 'F+F+F+F+F'
regole = {'F':'FF+F+F+F+F+FF'}  
disegno = sostituisci(assioma,regole,2)  
#print("D=",disegno)
angolo, passo = 72, .5   
hide() #per velocizzare il disegno
setcolor('black')
init()
left(90)
disegna(disegno,angolo,passo)
