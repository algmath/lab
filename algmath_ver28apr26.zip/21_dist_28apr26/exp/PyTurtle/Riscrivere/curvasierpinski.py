# File: curvasierpinsky ok
# Date: 6 gen 26
# Note: curva di Sierpinsky - <PyTurtle> 

#provare anche: cfr. https://www.kevs3d.co.uk/dev/lsystems/
#Axiom: L--F--L--F
#Rule1: L=+R-F-R+
#Rule2: R=-L+F+L-
#Angle: 45

from lsistemi import *

assioma = 'F--XF--F--XF'
regole = {'X':'XF+F+XF--F--XF+F+X'}  
disegno = sostituisci(assioma,regole,3)  
#print("D=",disegno)
angolo, passo = 45, .5

init()
hide() #per velocizzare il disegno
setcolor('black')
disegna(disegno,angolo,passo)
