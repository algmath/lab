# File: thue-morse.py - ok
# Date: 6 gen 26
# Note: successione di Thue-Morse - <PyTurtle>

from lsistemi import *  

#assioma = '0'
#regole = {'0':'01','1':'10'}  #..
assioma = '+'
regole = {'+':'+F','F':'F+'}  #..
for k in range(8):
    stringa = sostituisci(assioma,regole,k)
    #write("stringa="+stringa)
    #print("stringa=",stringa)

disegno = stringa #ultima generata
print("disegno=",disegno)
angolo, passo = 120, .2
#angolo, passo = -60, .2
init()
right(300)
disegna(disegno,angolo,passo)

