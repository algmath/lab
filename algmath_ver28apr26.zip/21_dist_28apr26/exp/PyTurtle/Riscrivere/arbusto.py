# File: arbusto.py - ok
# Date: 6 gen 26
# Note: arbusto - <PyTurtle>

#'''
from lsistemi import *

assioma = 'F'
regole = {'F':'F[+F]F[-F]'}  #bello
disegno = sostituisci(assioma,regole,4)  
#print("D=",disegno)
angolo, passo = 30, .2

#setpos(0,0)
#setangle(90)
#clear()
init() #clear del disegno e init t.

hide() #per velocizzare il disegno
setcolor('green4')
disegna(disegno,angolo,passo)
#'''

#home()
#init()
#clear()
#show()
#setcolor('red')
