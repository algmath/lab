# File: drago - ok
# Date: 6 gen 26
# Note: curva del drago - <PyTurtle>

from lsistemi import *

assioma = 'FX'
regole = {'X':'X+YF+', 'Y':'-FX-Y'}
disegno = sostituisci(assioma,regole,6)
angolo, passo = 90, .5
#print("D=",disegno)

init()
disegna(disegno,angolo,passo)


