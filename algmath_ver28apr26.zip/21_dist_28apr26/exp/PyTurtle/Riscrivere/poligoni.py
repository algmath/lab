# File: poligoni - ok
# Date: 6 gen 26
# Note: poligoni - <PyTurtle>

from lsistemi import *

assioma = 'X'
regole = {'X':'F+X'}       #poligono
#regole = {'X':'[F]+X'}     #raggiera
n = 12  #n. di lati/raggi
disegno = sostituisci(assioma,regole,n)  
#print("D=",disegno)
angolo, passo = 360/n, 1   
hide() #per velocizzare il disegno
setcolor('black')
init()
disegna(disegno,angolo,passo)
