# File: conigli.py - ok
# Date: 14 feb 26
# Note: conigli di Fibonacci - <PyTurtle>

#def .
#x = 
from lsistemi import *

#y=3/0

assioma = 'F'
#regole = {'F':'G','G':'GF'}  #ok per stringa lineare
#regole = {'F':'G','G':'[+[F]-]G'}  #prova 7feb26    ??
regole = {'F':'G','G':'F[+F]G'}  #ok [?]

#regole = {'F':'F[+F]F'}  #quasi
#regole = {'F':'FF[+F]'}  #no
for k in range(4): 
    popolazione = sostituisci(assioma,regole,k)
    #write("popolazione="+popolazione)
    #print("popolazione=",popolazione)

#z2(3)  #err

disegno = popolazione #ultima generata
print('disegno =',disegno)   #x
angolo, passo = 45, .5
#angolo, passo = 20, .5
init()
#left(90)
disegna(disegno,angolo,passo)
