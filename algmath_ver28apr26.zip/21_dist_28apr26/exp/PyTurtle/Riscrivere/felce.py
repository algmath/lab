# File: felce.py - ok
# Date: 6 gen 25
# Note: pianta di felce - <PyTurtle>

from lsistemi import *

assioma = 'X'
regole = {'X':'F[+X]F[-X]+X','F':'FF'}  #fig.1
#regole = {'X':'F[+X][-X]FX','F':'FF'}  #fig.2 prezzemolo
disegno = sostituisci(assioma,regole,5)  
#print("D=",disegno)
#angolo, passo = 18, .1  #fig.1
angolo, passo = 14, .1   #fig.2

init()
hide() #per velocizzare il disegno
setcolor('green4')
disegna(disegno,angolo,passo)
