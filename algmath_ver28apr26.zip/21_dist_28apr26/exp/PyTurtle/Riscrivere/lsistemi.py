# File: lsistemi.py - ok
# Date: 12 feb 26
# Note: modulo di funzioni per gli L-sistemi

from gwinter import *  #2apr25   RIM

#x = 1+y

#x = 1234+3)


#x=0
#y=3/x


#---- L-macchina ----
# a partire dall'assioma (per ciascun suo carattere) vengono applicate
# le regole (dizionario) eseguendo la sostituzione per niter volte;
# ritorna la stringa finale
#
def sostituisci(assioma:str,regole:dict,niter:int) -> str:
    if not regole is None:
       for i in range(niter):  
            ris = ""
            for c in assioma:
                ris = ris + regole.get(c,c) #get: se non c'e' c ritorna c
            assioma = ris
    return assioma


#---- Disegnatore ----
# traduce in disegno la stringa, applicando l'angolo di rotazione
# e disegnando un tratto al posto dei caratteri F
def disegna(stringa,angolo,passo):
    #show()
    pendown()  #h
    for c in stringa:
        if c == '+':
            right(angolo)
        elif c == '-':  
            left(angolo)
        #elif c == 'F':
        elif c in ('F','G'):  #per conigli Fibonacci
            forward(passo)
        elif c == '[':
            push()
        elif c == ']':
            pop()
        #else:
        #    print("comando errato :",b)
       

#---- Disegnatore ----
# genera la stringa di disegno e la disegna
#
def sost_disegna(assioma:str,regole:dict,niter:int,ang,passo=1):
    d = sostituisci(assioma,regole,niter)
    print('d = ',d)
    disegna(d,ang,passo)


        

