# File: turtles.py - <PyTurtle>
# Date: 22 apr 26
# Note: la grafica della tartaruga 
#       modalita' object-oriented
#       argomenti: tartarughe, oggetti, array

# inseguimento fra 2 t.
def inseguimento():
    t1 = Turtle(color='red')  
    t2 = Turtle(color='blue')
    mes = 'seleziona punto di partenza della tartaruga...'
    t1.move(Point(INPUT,msg=mes,state=DRAGGABLE,color=t1.getcolor()))
    message('')
    setmode(0) #esce dal modo INPUT e permette il drag del punto
    t2.move(Point(7,3))
    t1.show()
    t2.show()
    p = t2.pos()
    while t1.dist(t2.pos())>.01:
        t1.forward(.05)     # piu' lenta
        t2.forward(.06)     # piu' veloce
        t1.left(1)          # ruota di poco
        t2.look(t1.pos())   # orienta verso t1
            

#---- spirale di tartarughe ---- 
# n: numero di t.
def spiraletar(n:int):
    t = n*[None]
    colors = ['red','green','blue','orange','brown']
    for i in range(n):
        t[i] = Turtle(color=colors[i%len(colors)],width=1)
        t[i].left(360/n*i)
        t[i].show()
    for _ in range(40):
        for i in range(n):
           t[i].forward(.2)
           t[i].left(5)

#---- main ----
clear()
#inseguimento()    # inseguimento di 2 tartarughe 
spiraletar(7)      # spirale di tartarughe


