# File: figure.py 
# Date: 22 apr 26
# Note: disegno di figure (quadrato con diagonali, ...)

# quadrato di con diagonali di semilunghezza l
# con uso di push e pop
def quadratocondiagonali(lato:int):
    for _ in range(4):
        push()
        push()
        jump(lato)
        P = pos()
        pop()
        right(90)
        forward(lato)
        draw(P)
        pop()
        right(90)

#croce a 4 braccia
def croce4braccia(lato:int):
    for _ in range(4):  
        push()
        forward(lato)
        push()
        right(45)
        forward(lato)
        pop()   #esercizio: cosa avviene togliendo questa pop?
        left(45)
        forward(lato)
        pop()
        left(90)

       
#---- main ----
clear()
home()
setcolor('red')
quadratocondiagonali(2)
move(Point(2,3,state=INVISIBLE))
setcolor('blue')
croce4braccia(2)




    



    
