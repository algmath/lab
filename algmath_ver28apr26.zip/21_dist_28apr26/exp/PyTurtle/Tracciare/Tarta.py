# File: Tarta.py - <PyTurtle>
# Date: 2 apr 26
# Note: esempio con la grafica della tartaruga object-oriented
#       argomenti: tartarughe, oggetti, array

from gwinter import *    

#-------------------------------------------------
# estensione della classe Turtle:
# una Tarta e' una Turtle che non cambia colore
# e che ha un contatore dei passi
#
class Tarta(Turtle):

    # costruttore
    def __init__(self,col='black'):
        Turtle.__init__(self)
        super().setcolor(col)  
        self.show()
        self._passi = 0 # numero di passi percorsi
        Writing((80,70),"passi=[{0}]",variables=[self.npassi()],state=DRAGGABLE)  
       
    # metodo ridefinito   
    def forward(self, passi:float):  
        super().forward(passi)  
        self._passi += passi  
        
    # numero passi - valore dinamico  
    def npassi(self):
        return Value(lambda:self._passi,self.dpos())  
               
    # percorso fatto - valore statico   
    def percorso(self):
        return self._passi 
     
    # metodo aggiunto   
    def poligono(self, n:int, lato:float):
        for _ in range(n):
             self.forward(lato)
             self.left(360/n)
        
    # metodo mascherato   
    def setcolor(self, col:str):
        pass
        

