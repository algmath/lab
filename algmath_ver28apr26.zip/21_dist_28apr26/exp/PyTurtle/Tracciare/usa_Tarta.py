# File: usa_Tarta.py - <PyTurtle>
# Date: 22 apr 26
# Note: esempio d'uso della classe di oggetti Tarta

sys.path.append('../exp/Tracciare_PyTurtle')
from Tarta import *

#---- main ----
#grid()
clear()
P = Point(INPUT,msg='input punto...',color='red',state=DRAGGABLE)

t = Tarta('red')

t.move(Point(-3,-2))
t.draw(Point(1,4))
t.draw(Point(-1,2))
t.forward(2.5)

display('percorso:',t.percorso()) #valore statico
display('npassi:',t.npassi())     #valore dinamico

t.setcolor('green') # non ha effetto
t.poligono(7,3)


d = t.dpos().dist(P)
display('distanza dinamica:',d) 
display('distanza statica:',val(d))

T = t.pos()  #posizione fissa
display('distanza2:',T.dist(P))
D = t.pos()  #posizione dinamica
display('T = ',T)
display('D = ',D)  #posizione dinamica

#circ. di raggio var. che segue la t
c = Circle(D,d,color='blue',state=VISIBLE,width=MEDIUM)

k = 1
for _ in range(100):
    t.forward(k)
    t.left(90)
    k += .1

t.look(P)

   
