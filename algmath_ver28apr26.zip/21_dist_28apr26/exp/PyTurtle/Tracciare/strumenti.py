# File: strumenti.py - <PyTurtle>
# Date: 22 apr 26
# Note: uso della t. come strumento di disegno, di calcolo e di punti

# disegno di un segmento di dati estremi
def segmento(A:Point,B:Point) -> None:
    move(A)
    draw(B)
   
# distanza fra due dati punti (statica)
def distanza(A:Point,B:Point) -> float:
    move(A)
    return dist(B)

# punto medio fra due dati punti
def medio(A:Point,B:Point) -> Point:
    move(A)
    look(B)
    jump(dist(B)/2.)  
    return pos()

           
#---- main ----
clear()
home()
setcolor('blue')
message('input punto...')
A = Point(INPUT,state=INVISIBLE) 
B = Point(INPUT,state=INVISIBLE)
message('')
setcolor('red')
segmento(A,B)
d = distanza(A,B)
M = medio(A,B)
M.config(color='orange',state=VISIBLE)
display('distanza(A,B)=',d)
Writing((80,-50),"distanza(A,B)={0}",variables=[d],state=DRAGGABLE)
Writing((80,-70),"distanza(A,B)="+str(d),state=DRAGGABLE)
Writing((80,-90),"d="+str(d),state=DRAGGABLE,color='red')

       

    



    
