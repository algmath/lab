# File: hilbert.py - ok
# Date: 22 apr 26
# Note: curva di Hilbert - applicazione <PyTurtle>

# cfr. Turtle Geometry: The Computer as a Medium for Exploring Mathematics
# by Harold Abelson and Andrea diSessa p. 96-98
# l : lunghezza tratto
# n : ordine di ricorsione
# k : verso di avanzamento (-1,1)
#
def hilbert(l:float, n:int, k=1):
    if n > 0:
        left(k*90)
        hilbert(l,n-1,-k)
        forward(l)
        right(k*90)
        hilbert(l,n-1,k)
        forward(l)
        hilbert(l,n-1,k)
        right(k*90)
        forward(l)
        hilbert(l,n-1,-k)
        left(k*90)
       
#---- main ----
clear()
home()
setcolor('red')
#n = 3 #ordine di ricorsione
n = int(input('ordine di ricorsione:'))  
#show()
hilbert(.5,n)
#hide()



    



    
