# File: calcoli.py - <PyTurtle>
# Date: 22 apr 26
# Note: calcoli mediante la tartaruga

# radice di 2
def radice2():
    P = pos()
    jump(1)
    left(90)
    jump(1)
    return dist(P)

# radice di n
def radice(n:int) -> float:
    P = pos()   
    jump(1)
    for _ in range(n-1):
        look(P)
        right(90)
        jump(1)
    return dist(P)

#---- main ----
clear()
home()
hide()

for n in range(1,17):
    print(f'radice({n})=',radice(n),tim=0)    #sulla linea di comando
    display(f'radice({n})='+str(radice(n)))   #sulla finestra testo della GUI
     






    
