# File: chiudistanza.py
# Date: 24 apr 26
# Note: chiude una stanza rettangolare - cfr. problema 3.5.2
#       configurazione <PyQuad>

sys.path.append('../exp/PyQuad/Esplorare') 
from mod_ostacoli import *

def chiusastanza():
    return tocca(LEFT) and tocca(RIGHT) 

def muoviti():
    if tocca(FRONT):
        right()
    elif tocca(LEFT):
        forward()
        if not tocca(LEFT):
           left()
    else:
        forward()

# chiude una stanza rettangolare
def chiudistanza():
    while not chiusastanza():
        muoviti()
  
#---- main ----
chiudistanza()  

