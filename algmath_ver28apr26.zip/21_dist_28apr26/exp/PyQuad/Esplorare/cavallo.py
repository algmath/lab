# File: cavallo.py 
# Date: 24 apr 26
# Note: movimento a mossa di cavallo

def cavallo():
    for _ in range(2):
        forward()
    right()
    forward()
    
cavallo()





