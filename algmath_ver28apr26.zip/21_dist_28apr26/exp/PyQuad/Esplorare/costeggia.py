# File: costeggia.py - <PyQuad>
# Date: 23 apr 26
# Note: costeggia indefinitamente l'oggetto al quale si e' a contatto

sys.path.append('../exp/Esplorare_PyQuad')
from mod_ostacoli import *

# creazione del labirinto
def costeggia():
    affianca()
    while True:
        striscia()
        
#---- main ----
loadboard('../exp/PyQuad/Esplorare/costeggia.brd')  #per eseguire da AlgMath
#locate(3,2,EAST)  #posiziona Quadretto
right()
costeggia()






