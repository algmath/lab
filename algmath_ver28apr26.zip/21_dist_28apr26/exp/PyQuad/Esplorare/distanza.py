# File: distanza.py 
# Date: 23 apr 26
# Note: distanza dall'ostacolo davanti (sensore virtuale)
#       configurazione <PyQuad>

from mod_ostacoli import *

# distanza dall'ostacolo davanti
def distanza():
    d = 0
    if not touch():
        while not touch():
            forward()
            d += 1
        inverti()
        avanza(d)
        inverti()
    return d

#---- main ----
print('dist = ',distanza())

