# File: seguilinea.py
# Date: 27 apr 26
# Note: segue la linea di colore BLACK

sys.path.append('../exp/PyQuad/Esplorare') 
from mod_ostacoli import *

# usa il sensore 'basico'
def cercaPista():
    trovata = True
    if color() != BLACK: #se non c'e' linea nera davanti
        left()
        if color() != BLACK:
            #print('---> tocco a sinistra')
            inverti()
            if color() != BLACK:
                left()
                trovata = False
    return trovata

# segue la linea di caselle BLACK;
# si ferma quando si arriva in fondo
def seguiLinea():
    while cercaPista():
        forward()

#-------------- soluzione per appunti TeX --------------

# usa il sensore 'basico' ...
# orienta verso la linea BLACK;
# non fa niente se la linea BLACK e' davanti o se non c'e' linea sui lati
def cercaLinea():
    if color() != BLACK: #se non c'e' linea nera davanti
        left()
        if color() != BLACK:
            inverti()
            if color() != BLACK:
                left() #linea BLACK non trovata

# segue la linea di colore BLACK - soluzione MIGLIORE
def seguiLinea1():
    while color() == BLACK:
        forward()
        cercaLinea()
    forward() #ultimo passo per uuscire dalla linea    
      
#--------------------------------------------------------

# segue la linea di colore BLACK - usa sensore derivato
def seguiLinea2():
    while color() == BLACK:
        forward()
        if color(LEFT)==BLACK:
            left()
        elif color(RIGHT)==BLACK:
            right()
   
#---- main ----
#cercaLinea()
            
#seguiLinea()  #ok
#seguiLine1()  #x appunti TeX
seguiLinea2()  #con sensore derivato 






