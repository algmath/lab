# File: orientanord.py - <PyQuad> 
# Date: 24 apr 26
# Note: orienta Q verso Nord

def orienta(v):
    while angle() != v:
        left()

orienta(NORTH)

