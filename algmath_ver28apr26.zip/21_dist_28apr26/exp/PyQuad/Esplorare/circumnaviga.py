# File: circumnaviga.py - ok
# Date: 23 apr 26
# Note: circuita un oggetto e ritorna al punto di partenza

sys.path.append('../exp/Esplorare_PyQuad')
from mod_ostacoli import *

# circuita un oggetto e ritorna al punto di partenza
def circumnaviga(): 
    x, y, v = posc(), posr(), angle() #stato iniziale
    affianca()
    while True:
        striscia()
        if ((posc()==x) and (posr()==y)): break
    orienta(v)
    
#---- main ----
loadboard('../exp/PyQuad/Esplorare/costeggia.brd')  
#locate(3,2,EAST)  #posiziona Quadretto
right()
circumnaviga()
